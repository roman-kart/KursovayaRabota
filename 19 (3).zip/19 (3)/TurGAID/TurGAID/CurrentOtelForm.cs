﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class CurrentOtelForm : Form
    {
        public Model1 DB { get; set; }
        public Otel kl { get; set; }
        public CurrentOtelForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (kl == null)
            {
                kl = (Otel)otelBindingSource.List[0];
                DB.Otel.Add(kl);
            }
            try
            {
                DB.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Ошибка " + ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void CurrentOtelForm_Load(object sender, EventArgs e)
        {
            if (kl == null)
            {
                otelBindingSource.AddNew();

                Text = " Добавление нового отеля ";
            }
            else
            {
                otelBindingSource.Add(kl);
                iD_OtelTextBox.ReadOnly = true;
                Text = " Корректировка отеля " + kl.ID_Otel;
            }
        }
    }
}
