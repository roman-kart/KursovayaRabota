namespace TurGAID
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Strana")]
    public partial class Strana
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Strana()
        {
            Kurort = new HashSet<Kurort>();
        }

        [Key]
        public int ID_strana { get; set; }

        [Required]
        [StringLength(50)]
        public string Strana1 { get; set; }

        [Required]
        [StringLength(50)]
        public string Stolitsya { get; set; }

        [Required]
        [StringLength(50)]
        public string Yazik { get; set; }

        [Required]
        [StringLength(50)]
        public string Money { get; set; }

        [Column(TypeName = "image")]
        public byte[] Karta { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Kurort> Kurort { get; set; }
    }
}
