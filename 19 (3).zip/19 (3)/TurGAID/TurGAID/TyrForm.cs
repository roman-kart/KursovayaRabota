﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class TyrForm : Form
    {
        Model1 DB = new Model1();
        public TyrForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CurrentTyrForm frm = new CurrentTyrForm();
            frm.DB = DB;
            frm.kl = null;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                //tyrBindingSource.DataSource = null;
                tyrBindingSource.DataSource = DB.Tyr.ToList();
            }
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Tyr kl = (Tyr)tyrBindingSource.Current;
            CurrentTyrForm frm = new CurrentTyrForm();
            frm.DB = DB;
            frm.kl = kl;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                //tyrBindingSource.DataSource = null;
                tyrBindingSource.DataSource = DB.Tyr.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Tyr kl = (Tyr)tyrBindingSource.Current;
            DialogResult dr = MessageBox.Show(" Удалить " +
              kl.ID_tyr + "?", " Удаление ",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                if (kl.Prodazha.Count == 0)
                {
                    DB.Tyr.Remove(kl);
                }
                else
                {
                    MessageBox.Show("Для удаления тура необходимо удалить связанные с туром продажи!");
                }
                try
                {
                    DB.SaveChanges();
                    tyrBindingSource.DataSource = DB.Tyr.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.InnerException.InnerException.Message);
                }
            }
        }

        private void TyrForm_Load(object sender, EventArgs e)
        {
            tyrBindingSource.DataSource = DB.Tyr.ToList();
            kurortBindingSource.DataSource = DB.Kurort.ToList();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainForm frm = new MainForm();
            this.Hide();
            frm.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                var tyri = from tyr in DB.Tyr.ToList()
                           where this.isCorrect(tyr)
                           select tyr;
            this.tyrBindingSource.DataSource = tyri.ToList();
            }
            catch (IndexOutOfRangeException ex)
            {
                MessageBox.Show("Заполните параметры для поиска.");
            }
            catch (ArgumentOutOfRangeException ex)
            {
                MessageBox.Show("Заполните параметры для поиска.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неизвестная ошибка! Обратитесь к системному администратору.");
            }
        }
        private bool isCorrect(TurGAID.Tyr tyr)
        {
            bool isChecked = false;
            bool isCorrect = true;
            if (tourName_checkBox4.Checked && (tourName_textBox.Text == tyr.Tyr1))
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (tour_time_checkBox1.Checked && (tourName_textBox.Text == tyr.Time))
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (id_kurort_checkBox2.Checked && (DB.Kurort.ToList()[ID_Kurort_comboBox1.SelectedIndex].ID_Kurort == tyr.ID_Kurort))
            {
                isCorrect &= true;
                isChecked = true;
            }

            return isCorrect && isChecked;
        }
    }
}
