﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class CurrentTyrForm : Form
    {
        public Model1 DB { get; set; }
        public Tyr kl { get; set; }
        public CurrentTyrForm()
        {
            InitializeComponent();
        }

        private void CurrentTyrForm_Load(object sender, EventArgs e)
        {
            this.kurortBindingSource.DataSource = DB.Kurort.ToList();
            if (kl == null)
            {
                tyrBindingSource.AddNew();

                Text = " Добавление нового тура ";
            }
            else
            {
                tyrBindingSource.Add(kl);
                iD_tyrTextBox.ReadOnly = true;
                Text = " Корректировка тура " + kl.ID_tyr;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (kl == null)
            {
                kl = (Tyr)tyrBindingSource.List[0];
                DB.Tyr.Add(kl);
            }
            try
            {
                DB.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Ошибка " + ex.InnerException.InnerException.Message);
            }
        }
    }
}
