﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class CurrentKurortForm : Form
    {
        public Model1 DB { get; set; }
        public Kurort kl { get; set; }
        public CurrentKurortForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (kl == null)
            {
                kl = (Kurort)kurortBindingSource.List[0];
                DB.Kurort.Add(kl);
            }
            try
            {
                DB.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Ошибка " + ex.InnerException.InnerException.Message);
            }
        }

        private void CurrentKurortForm_Load(object sender, EventArgs e)
        {
            if (kl == null)
            {
                kurortBindingSource.AddNew();
                this.stranaBindingSource.DataSource = DB.Strana.ToList();

                Text = " Добавление нового курорта ";
                this.iD_stranaComboBox.SelectedIndex = -1;
            }
            else
            {
                this.stranaBindingSource.DataSource = DB.Strana.ToList();
                kurortBindingSource.Add(kl);
                iD_KurortTextBox.ReadOnly = true;
                Text = " Корректировка курорта " + kl.ID_Kurort;
            }
        }
    }
}
