﻿
namespace TurGAID
{
    partial class TyrForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label stoimostLabel;
            System.Windows.Forms.Label label1;
            this.tyrDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.kurortBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tyrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.tourName_checkBox4 = new System.Windows.Forms.CheckBox();
            this.tourName_textBox = new System.Windows.Forms.TextBox();
            this.tour_time_checkBox1 = new System.Windows.Forms.CheckBox();
            this.tourTime_textBox = new System.Windows.Forms.TextBox();
            this.ID_Kurort_comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.id_kurort_checkBox2 = new System.Windows.Forms.CheckBox();
            stoimostLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tyrDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurortBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tyrBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // stoimostLabel
            // 
            stoimostLabel.AutoSize = true;
            stoimostLabel.Location = new System.Drawing.Point(37, 341);
            stoimostLabel.Name = "stoimostLabel";
            stoimostLabel.Size = new System.Drawing.Size(85, 13);
            stoimostLabel.TabIndex = 41;
            stoimostLabel.Text = "Название тура:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(37, 367);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(131, 13);
            label1.TabIndex = 44;
            label1.Text = "Время проведения тура:";
            // 
            // tyrDataGridView
            // 
            this.tyrDataGridView.AutoGenerateColumns = false;
            this.tyrDataGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tyrDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tyrDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.tyrDataGridView.DataSource = this.tyrBindingSource;
            this.tyrDataGridView.Location = new System.Drawing.Point(0, 0);
            this.tyrDataGridView.Name = "tyrDataGridView";
            this.tyrDataGridView.Size = new System.Drawing.Size(442, 220);
            this.tyrDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID_tyr";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID Тура";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Tyr1";
            this.dataGridViewTextBoxColumn2.HeaderText = "Название тура";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Time";
            this.dataGridViewTextBoxColumn3.HeaderText = "Время проведения тура";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "ID_Kurort";
            this.dataGridViewTextBoxColumn4.DataSource = this.kurortBindingSource;
            this.dataGridViewTextBoxColumn4.DisplayMember = "Kurort1";
            this.dataGridViewTextBoxColumn4.HeaderText = "ID Курорта";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn4.ValueMember = "ID_Kurort";
            // 
            // kurortBindingSource
            // 
            this.kurortBindingSource.DataSource = typeof(TurGAID.Kurort);
            // 
            // tyrBindingSource
            // 
            this.tyrBindingSource.DataSource = typeof(TurGAID.Tyr);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button5.Location = new System.Drawing.Point(97, 278);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(115, 46);
            this.button5.TabIndex = 11;
            this.button5.Text = "Выйти из приложения";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.LightGreen;
            this.button4.Location = new System.Drawing.Point(218, 278);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(115, 46);
            this.button4.TabIndex = 10;
            this.button4.Text = "Вернуться в главное меню";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button3.Location = new System.Drawing.Point(282, 226);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(115, 46);
            this.button3.TabIndex = 9;
            this.button3.Text = "Удалить";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.Location = new System.Drawing.Point(161, 226);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 46);
            this.button2.TabIndex = 8;
            this.button2.Text = "Изменить";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(40, 226);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 46);
            this.button1.TabIndex = 7;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.LightGreen;
            this.button6.Location = new System.Drawing.Point(53, 427);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(342, 46);
            this.button6.TabIndex = 18;
            this.button6.Text = "Найти";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // tourName_checkBox4
            // 
            this.tourName_checkBox4.AutoSize = true;
            this.tourName_checkBox4.Location = new System.Drawing.Point(401, 341);
            this.tourName_checkBox4.Name = "tourName_checkBox4";
            this.tourName_checkBox4.Size = new System.Drawing.Size(15, 14);
            this.tourName_checkBox4.TabIndex = 42;
            this.tourName_checkBox4.UseVisualStyleBackColor = true;
            // 
            // tourName_textBox
            // 
            this.tourName_textBox.Location = new System.Drawing.Point(195, 338);
            this.tourName_textBox.Name = "tourName_textBox";
            this.tourName_textBox.Size = new System.Drawing.Size(200, 20);
            this.tourName_textBox.TabIndex = 40;
            // 
            // tour_time_checkBox1
            // 
            this.tour_time_checkBox1.AutoSize = true;
            this.tour_time_checkBox1.Location = new System.Drawing.Point(401, 367);
            this.tour_time_checkBox1.Name = "tour_time_checkBox1";
            this.tour_time_checkBox1.Size = new System.Drawing.Size(15, 14);
            this.tour_time_checkBox1.TabIndex = 45;
            this.tour_time_checkBox1.UseVisualStyleBackColor = true;
            // 
            // tourTime_textBox
            // 
            this.tourTime_textBox.Location = new System.Drawing.Point(195, 364);
            this.tourTime_textBox.Name = "tourTime_textBox";
            this.tourTime_textBox.Size = new System.Drawing.Size(200, 20);
            this.tourTime_textBox.TabIndex = 43;
            // 
            // ID_Kurort_comboBox1
            // 
            this.ID_Kurort_comboBox1.DataSource = this.kurortBindingSource;
            this.ID_Kurort_comboBox1.DisplayMember = "Kurort1";
            this.ID_Kurort_comboBox1.FormattingEnabled = true;
            this.ID_Kurort_comboBox1.Location = new System.Drawing.Point(195, 390);
            this.ID_Kurort_comboBox1.Name = "ID_Kurort_comboBox1";
            this.ID_Kurort_comboBox1.Size = new System.Drawing.Size(200, 21);
            this.ID_Kurort_comboBox1.TabIndex = 47;
            this.ID_Kurort_comboBox1.ValueMember = "ID_Kurort";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 393);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 46;
            this.label2.Text = "ID Курорта:";
            // 
            // id_kurort_checkBox2
            // 
            this.id_kurort_checkBox2.AutoSize = true;
            this.id_kurort_checkBox2.Location = new System.Drawing.Point(401, 393);
            this.id_kurort_checkBox2.Name = "id_kurort_checkBox2";
            this.id_kurort_checkBox2.Size = new System.Drawing.Size(15, 14);
            this.id_kurort_checkBox2.TabIndex = 48;
            this.id_kurort_checkBox2.UseVisualStyleBackColor = true;
            // 
            // TyrForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(442, 483);
            this.Controls.Add(this.id_kurort_checkBox2);
            this.Controls.Add(this.ID_Kurort_comboBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tour_time_checkBox1);
            this.Controls.Add(label1);
            this.Controls.Add(this.tourTime_textBox);
            this.Controls.Add(this.tourName_checkBox4);
            this.Controls.Add(stoimostLabel);
            this.Controls.Add(this.tourName_textBox);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tyrDataGridView);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(458, 522);
            this.MinimumSize = new System.Drawing.Size(458, 522);
            this.Name = "TyrForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Туры";
            this.Load += new System.EventHandler(this.TyrForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tyrDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurortBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tyrBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource tyrBindingSource;
        private System.Windows.Forms.DataGridView tyrDataGridView;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.BindingSource kurortBindingSource;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.CheckBox tourName_checkBox4;
        private System.Windows.Forms.TextBox tourName_textBox;
        private System.Windows.Forms.CheckBox tour_time_checkBox1;
        private System.Windows.Forms.TextBox tourTime_textBox;
        private System.Windows.Forms.ComboBox ID_Kurort_comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox id_kurort_checkBox2;
    }
}