﻿
namespace TurGAID
{
    partial class CurrentOtelForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iD_OtelLabel;
            System.Windows.Forms.Label klass_OtelLabel;
            this.iD_OtelTextBox = new System.Windows.Forms.TextBox();
            this.otelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.klass_OtelTextBox = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            iD_OtelLabel = new System.Windows.Forms.Label();
            klass_OtelLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.otelBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // iD_OtelLabel
            // 
            iD_OtelLabel.AutoSize = true;
            iD_OtelLabel.Location = new System.Drawing.Point(10, 84);
            iD_OtelLabel.Name = "iD_OtelLabel";
            iD_OtelLabel.Size = new System.Drawing.Size(55, 13);
            iD_OtelLabel.TabIndex = 1;
            iD_OtelLabel.Text = "ID Отеля:";
            iD_OtelLabel.Visible = false;
            // 
            // klass_OtelLabel
            // 
            klass_OtelLabel.AutoSize = true;
            klass_OtelLabel.Location = new System.Drawing.Point(10, 15);
            klass_OtelLabel.Name = "klass_OtelLabel";
            klass_OtelLabel.Size = new System.Drawing.Size(75, 13);
            klass_OtelLabel.TabIndex = 3;
            klass_OtelLabel.Text = "Класс Отеля:";
            // 
            // iD_OtelTextBox
            // 
            this.iD_OtelTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.otelBindingSource, "ID_Otel", true));
            this.iD_OtelTextBox.Location = new System.Drawing.Point(90, 81);
            this.iD_OtelTextBox.Name = "iD_OtelTextBox";
            this.iD_OtelTextBox.Size = new System.Drawing.Size(200, 20);
            this.iD_OtelTextBox.TabIndex = 2;
            this.iD_OtelTextBox.Visible = false;
            // 
            // otelBindingSource
            // 
            this.otelBindingSource.DataSource = typeof(TurGAID.Otel);
            // 
            // klass_OtelTextBox
            // 
            this.klass_OtelTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.otelBindingSource, "Klass_Otel", true));
            this.klass_OtelTextBox.Location = new System.Drawing.Point(90, 12);
            this.klass_OtelTextBox.Name = "klass_OtelTextBox";
            this.klass_OtelTextBox.Size = new System.Drawing.Size(200, 20);
            this.klass_OtelTextBox.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(171, 40);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 46);
            this.button2.TabIndex = 16;
            this.button2.Text = "Вернуться";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(20, 40);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 46);
            this.button1.TabIndex = 15;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CurrentOtelForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(302, 101);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(iD_OtelLabel);
            this.Controls.Add(this.iD_OtelTextBox);
            this.Controls.Add(klass_OtelLabel);
            this.Controls.Add(this.klass_OtelTextBox);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(318, 140);
            this.MinimumSize = new System.Drawing.Size(318, 140);
            this.Name = "CurrentOtelForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Текущий отель";
            this.Load += new System.EventHandler(this.CurrentOtelForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.otelBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource otelBindingSource;
        private System.Windows.Forms.TextBox iD_OtelTextBox;
        private System.Windows.Forms.TextBox klass_OtelTextBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}