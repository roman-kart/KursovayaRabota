namespace TurGAID
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Tyr")]
    public partial class Tyr
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Tyr()
        {
            Prodazha = new HashSet<Prodazha>();
        }

        [Key]
        public int ID_tyr { get; set; }

        [Required]
        [StringLength(50)]
        public string Tyr1 { get; set; }

        [Required]
        [StringLength(50)]
        public string Time { get; set; }

        public int ID_Kurort { get; set; }

        public virtual Kurort Kurort { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Prodazha> Prodazha { get; set; }
    }
}
