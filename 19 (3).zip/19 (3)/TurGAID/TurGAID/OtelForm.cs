﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class OtelForm : Form
    {
        Model1 DB = new Model1();
        public OtelForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CurrentOtelForm frm = new CurrentOtelForm();
            frm.DB = DB;
            frm.kl = null;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                //otelBindingSource.DataSource = null;
                otelBindingSource.DataSource = DB.Otel.ToList();
            }
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Otel kl = (Otel)otelBindingSource.Current;
            CurrentOtelForm frm = new CurrentOtelForm();
            frm.DB = DB;
            frm.kl = kl;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                //otelBindingSource.DataSource = null;
                otelBindingSource.DataSource = DB.Otel.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Otel kl = (Otel)otelBindingSource.Current;
            DialogResult dr = MessageBox.Show(" Удалить " +
              kl.ID_Otel + "?", " Удаление ",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                if (kl.Prodazha.Count == 0)
                {
                    DB.Otel.Remove(kl);
                }
                else
                {
                    MessageBox.Show("Для удаления отеля необходимо удалить связанные с отелем продажи!");
                }
                try
                {
                    DB.SaveChanges();
                    otelBindingSource.DataSource = DB.Otel.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.InnerException.InnerException.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainForm frm = new MainForm();
            this.Hide();
            frm.Show();
        }

        private void OtelForm_Load(object sender, EventArgs e)
        {
            otelBindingSource.DataSource = DB.Otel.ToList();
        }
    }
}
