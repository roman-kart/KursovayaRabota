﻿
namespace TurGAID
{
    partial class CurrentKurortForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iD_KurortLabel;
            System.Windows.Forms.Label kurort1Label;
            System.Windows.Forms.Label iD_stranaLabel1;
            this.iD_KurortTextBox = new System.Windows.Forms.TextBox();
            this.kurortBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kurort1TextBox = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.iD_stranaComboBox = new System.Windows.Forms.ComboBox();
            this.stranaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kurortBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            iD_KurortLabel = new System.Windows.Forms.Label();
            kurort1Label = new System.Windows.Forms.Label();
            iD_stranaLabel1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.kurortBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stranaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurortBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // iD_KurortLabel
            // 
            iD_KurortLabel.AutoSize = true;
            iD_KurortLabel.Location = new System.Drawing.Point(12, 104);
            iD_KurortLabel.Name = "iD_KurortLabel";
            iD_KurortLabel.Size = new System.Drawing.Size(65, 13);
            iD_KurortLabel.TabIndex = 1;
            iD_KurortLabel.Text = "ID Курорта:";
            iD_KurortLabel.Visible = false;
            // 
            // kurort1Label
            // 
            kurort1Label.AutoSize = true;
            kurort1Label.Location = new System.Drawing.Point(12, 38);
            kurort1Label.Name = "kurort1Label";
            kurort1Label.Size = new System.Drawing.Size(104, 13);
            kurort1Label.TabIndex = 5;
            kurort1Label.Text = "Название Курорта:";
            // 
            // iD_stranaLabel1
            // 
            iD_stranaLabel1.AutoSize = true;
            iD_stranaLabel1.Location = new System.Drawing.Point(12, 9);
            iD_stranaLabel1.Name = "iD_stranaLabel1";
            iD_stranaLabel1.Size = new System.Drawing.Size(62, 13);
            iD_stranaLabel1.TabIndex = 18;
            iD_stranaLabel1.Text = "ID Страны:";
            // 
            // iD_KurortTextBox
            // 
            this.iD_KurortTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.kurortBindingSource, "ID_Kurort", true));
            this.iD_KurortTextBox.Location = new System.Drawing.Point(121, 101);
            this.iD_KurortTextBox.Name = "iD_KurortTextBox";
            this.iD_KurortTextBox.Size = new System.Drawing.Size(200, 20);
            this.iD_KurortTextBox.TabIndex = 4;
            this.iD_KurortTextBox.Visible = false;
            // 
            // kurortBindingSource
            // 
            this.kurortBindingSource.DataSource = typeof(TurGAID.Kurort);
            // 
            // kurort1TextBox
            // 
            this.kurort1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.kurortBindingSource, "Kurort1", true));
            this.kurort1TextBox.Location = new System.Drawing.Point(121, 35);
            this.kurort1TextBox.Name = "kurort1TextBox";
            this.kurort1TextBox.Size = new System.Drawing.Size(200, 20);
            this.kurort1TextBox.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(185, 65);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 46);
            this.button2.TabIndex = 18;
            this.button2.Text = "Вернуться";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(34, 65);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 46);
            this.button1.TabIndex = 17;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // iD_stranaComboBox
            // 
            this.iD_stranaComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.kurortBindingSource, "ID_strana", true));
            this.iD_stranaComboBox.DataSource = this.stranaBindingSource;
            this.iD_stranaComboBox.DisplayMember = "Strana1";
            this.iD_stranaComboBox.FormattingEnabled = true;
            this.iD_stranaComboBox.Location = new System.Drawing.Point(121, 8);
            this.iD_stranaComboBox.Name = "iD_stranaComboBox";
            this.iD_stranaComboBox.Size = new System.Drawing.Size(200, 21);
            this.iD_stranaComboBox.TabIndex = 19;
            this.iD_stranaComboBox.ValueMember = "ID_strana";
            // 
            // stranaBindingSource
            // 
            this.stranaBindingSource.DataSource = typeof(TurGAID.Strana);
            // 
            // kurortBindingSource1
            // 
            this.kurortBindingSource1.DataSource = typeof(TurGAID.Kurort);
            // 
            // CurrentKurortForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(341, 141);
            this.Controls.Add(iD_stranaLabel1);
            this.Controls.Add(this.iD_stranaComboBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(iD_KurortLabel);
            this.Controls.Add(this.iD_KurortTextBox);
            this.Controls.Add(kurort1Label);
            this.Controls.Add(this.kurort1TextBox);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(357, 180);
            this.MinimumSize = new System.Drawing.Size(357, 180);
            this.Name = "CurrentKurortForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Текущий курорт";
            this.Load += new System.EventHandler(this.CurrentKurortForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kurortBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stranaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurortBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource kurortBindingSource;
        private System.Windows.Forms.TextBox iD_KurortTextBox;
        private System.Windows.Forms.TextBox kurort1TextBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox iD_stranaComboBox;
        private System.Windows.Forms.BindingSource stranaBindingSource;
        private System.Windows.Forms.BindingSource kurortBindingSource1;
    }
}