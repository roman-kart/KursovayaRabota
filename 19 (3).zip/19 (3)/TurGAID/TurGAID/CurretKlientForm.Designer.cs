﻿
namespace TurGAID
{
    partial class CurretKlientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label adresLabel;
            System.Windows.Forms.Label data_rozhdeniaLabel;
            System.Windows.Forms.Label familiaLabel;
            System.Windows.Forms.Label iD_klientLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label otchestvoLabel;
            this.adresTextBox = new System.Windows.Forms.TextBox();
            this.data_rozhdeniaDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.familiaTextBox = new System.Windows.Forms.TextBox();
            this.iD_klientTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.otchestvoTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.klientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            adresLabel = new System.Windows.Forms.Label();
            data_rozhdeniaLabel = new System.Windows.Forms.Label();
            familiaLabel = new System.Windows.Forms.Label();
            iD_klientLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            otchestvoLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.klientBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // adresLabel
            // 
            adresLabel.AutoSize = true;
            adresLabel.Location = new System.Drawing.Point(34, 126);
            adresLabel.Name = "adresLabel";
            adresLabel.Size = new System.Drawing.Size(41, 13);
            adresLabel.TabIndex = 1;
            adresLabel.Text = "Адрес:";
            // 
            // data_rozhdeniaLabel
            // 
            data_rozhdeniaLabel.AutoSize = true;
            data_rozhdeniaLabel.Location = new System.Drawing.Point(34, 103);
            data_rozhdeniaLabel.Name = "data_rozhdeniaLabel";
            data_rozhdeniaLabel.Size = new System.Drawing.Size(89, 13);
            data_rozhdeniaLabel.TabIndex = 3;
            data_rozhdeniaLabel.Text = "Дата рождения:";
            // 
            // familiaLabel
            // 
            familiaLabel.AutoSize = true;
            familiaLabel.Location = new System.Drawing.Point(34, 22);
            familiaLabel.Name = "familiaLabel";
            familiaLabel.Size = new System.Drawing.Size(59, 13);
            familiaLabel.TabIndex = 5;
            familiaLabel.Text = "Фамилия:";
            // 
            // iD_klientLabel
            // 
            iD_klientLabel.AutoSize = true;
            iD_klientLabel.Location = new System.Drawing.Point(34, 197);
            iD_klientLabel.Name = "iD_klientLabel";
            iD_klientLabel.Size = new System.Drawing.Size(21, 13);
            iD_klientLabel.TabIndex = 7;
            iD_klientLabel.Text = "ID:";
            iD_klientLabel.Visible = false;
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(34, 48);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(32, 13);
            nameLabel.TabIndex = 9;
            nameLabel.Text = "Имя:";
            // 
            // otchestvoLabel
            // 
            otchestvoLabel.AutoSize = true;
            otchestvoLabel.Location = new System.Drawing.Point(34, 74);
            otchestvoLabel.Name = "otchestvoLabel";
            otchestvoLabel.Size = new System.Drawing.Size(57, 13);
            otchestvoLabel.TabIndex = 11;
            otchestvoLabel.Text = "Отчество:";
            // 
            // adresTextBox
            // 
            this.adresTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientBindingSource, "Adres", true));
            this.adresTextBox.Location = new System.Drawing.Point(135, 123);
            this.adresTextBox.Name = "adresTextBox";
            this.adresTextBox.Size = new System.Drawing.Size(200, 20);
            this.adresTextBox.TabIndex = 5;
            // 
            // data_rozhdeniaDateTimePicker
            // 
            this.data_rozhdeniaDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.klientBindingSource, "Data_rozhdenia", true));
            this.data_rozhdeniaDateTimePicker.Location = new System.Drawing.Point(135, 97);
            this.data_rozhdeniaDateTimePicker.Name = "data_rozhdeniaDateTimePicker";
            this.data_rozhdeniaDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.data_rozhdeniaDateTimePicker.TabIndex = 4;
            // 
            // familiaTextBox
            // 
            this.familiaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientBindingSource, "Familia", true));
            this.familiaTextBox.Location = new System.Drawing.Point(135, 19);
            this.familiaTextBox.Name = "familiaTextBox";
            this.familiaTextBox.Size = new System.Drawing.Size(200, 20);
            this.familiaTextBox.TabIndex = 1;
            // 
            // iD_klientTextBox
            // 
            this.iD_klientTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientBindingSource, "ID_klient", true));
            this.iD_klientTextBox.Location = new System.Drawing.Point(135, 194);
            this.iD_klientTextBox.Name = "iD_klientTextBox";
            this.iD_klientTextBox.Size = new System.Drawing.Size(200, 20);
            this.iD_klientTextBox.TabIndex = 8;
            this.iD_klientTextBox.Visible = false;
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(135, 45);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(200, 20);
            this.nameTextBox.TabIndex = 2;
            // 
            // otchestvoTextBox
            // 
            this.otchestvoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientBindingSource, "Otchestvo", true));
            this.otchestvoTextBox.Location = new System.Drawing.Point(135, 71);
            this.otchestvoTextBox.Name = "otchestvoTextBox";
            this.otchestvoTextBox.Size = new System.Drawing.Size(200, 20);
            this.otchestvoTextBox.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(40, 153);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 46);
            this.button1.TabIndex = 6;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(213, 153);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 46);
            this.button2.TabIndex = 7;
            this.button2.Text = "Вернуться";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // klientBindingSource
            // 
            this.klientBindingSource.DataSource = typeof(TurGAID.Klient);
            // 
            // CurretKlientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(374, 244);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(adresLabel);
            this.Controls.Add(this.adresTextBox);
            this.Controls.Add(data_rozhdeniaLabel);
            this.Controls.Add(this.data_rozhdeniaDateTimePicker);
            this.Controls.Add(familiaLabel);
            this.Controls.Add(this.familiaTextBox);
            this.Controls.Add(iD_klientLabel);
            this.Controls.Add(this.iD_klientTextBox);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(otchestvoLabel);
            this.Controls.Add(this.otchestvoTextBox);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(390, 283);
            this.MinimumSize = new System.Drawing.Size(390, 283);
            this.Name = "CurretKlientForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Текущий клиент";
            this.Load += new System.EventHandler(this.CurretKlientForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.klientBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource klientBindingSource;
        private System.Windows.Forms.TextBox adresTextBox;
        private System.Windows.Forms.DateTimePicker data_rozhdeniaDateTimePicker;
        private System.Windows.Forms.TextBox familiaTextBox;
        private System.Windows.Forms.TextBox iD_klientTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox otchestvoTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}