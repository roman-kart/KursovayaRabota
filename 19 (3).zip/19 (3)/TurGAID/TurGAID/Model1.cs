using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace TurGAID
{
    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model11")
        {
        }

        public virtual DbSet<Klient> Klient { get; set; }
        public virtual DbSet<Kurort> Kurort { get; set; }
        public virtual DbSet<Otel> Otel { get; set; }
        public virtual DbSet<Prodazha> Prodazha { get; set; }
        public virtual DbSet<Strana> Strana { get; set; }
        public virtual DbSet<Tyr> Tyr { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Klient>()
                .HasMany(e => e.Prodazha)
                .WithRequired(e => e.Klient)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Kurort>()
                .HasMany(e => e.Tyr)
                .WithRequired(e => e.Kurort)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Otel>()
                .HasMany(e => e.Prodazha)
                .WithRequired(e => e.Otel)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Prodazha>()
                .Property(e => e.Stoimost)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Strana>()
                .HasMany(e => e.Kurort)
                .WithRequired(e => e.Strana)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Tyr>()
                .HasMany(e => e.Prodazha)
                .WithRequired(e => e.Tyr)
                .WillCascadeOnDelete(false);
        }
    }
}
