﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class StranaForm : Form
    {
        Model1 DB = new Model1();
        public StranaForm()
        {
            InitializeComponent();
        }

        private void StranaForm_Load(object sender, EventArgs e)
        {
            stranaBindingSource.DataSource = DB.Strana.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CurretStranaForm frm = new CurretStranaForm();
            frm.DB = DB;
            frm.st = null;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                //stranaBindingSource.DataSource = null;
                stranaBindingSource.DataSource = DB.Strana.ToList();
            }
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Strana st = (Strana)stranaBindingSource.Current;
            CurretStranaForm frm = new CurretStranaForm();
            frm.DB = DB;
            frm.st = st;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                stranaBindingSource.DataSource = DB.Strana.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Strana st = (Strana)stranaBindingSource.Current;
            DialogResult dr = MessageBox.Show(" Удалить " +
              st.ID_strana + "?", " Удаление ",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                if (st.Kurort.Count == 0)
                {
                    DB.Strana.Remove(st);
                }
                else
                {
                    MessageBox.Show("Для удаления страны необходимо удалить связанные со страной курорты!");
                }
                try
                {
                    DB.SaveChanges();
                    stranaBindingSource.DataSource = DB.Strana.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.InnerException.InnerException.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainForm frm = new MainForm();
            this.Hide();
            frm.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
            try
            {
                var strani = from strana in DB.Strana.ToList()
                           where this.isCorrect(strana)
                           select strana;
            this.stranaBindingSource.DataSource = strani.ToList();
            }
            catch (IndexOutOfRangeException ex)
            {
                MessageBox.Show("Заполните параметры для поиска.");
            }
            catch (ArgumentOutOfRangeException ex)
            {
                MessageBox.Show("Заполните параметры для поиска.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неизвестная ошибка! Обратитесь к системному администратору.");
            }
        }
        private bool isCorrect(TurGAID.Strana strana)
        {
            bool isChecked = false;
            bool isCorrect = true;
            if (countryName_checkBox4.Checked && (countryName_textBox.Text == strana.Strana1))
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (capitalName_checkBox1.Checked && (capitalName_textBox1.Text == strana.Stolitsya))
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (languageName_checkBox2.Checked && (languageName_textBox2.Text == strana.Yazik))
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (nationalCurrency_checkBox3.Checked && (natioanlCurrency_textBox3.Text == strana.Money))
            {
                isCorrect &= true;
                isChecked = true;
            }

            return isCorrect && isChecked;
        }
    }
}
