﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class CurretStranaForm : Form
    {
        public Model1 DB { get; set; }
        public Strana st { get; set; }
        public CurretStranaForm()
        {
            InitializeComponent();
        }

        private void CurretStranaForm_Load(object sender, EventArgs e)
        {
            if (st == null)
            {
                stranaBindingSource.AddNew();

                Text = " Добавление новой страны ";
            }
            else
            {
                stranaBindingSource.Add(st);
                iD_stranaTextBox.ReadOnly = true;
                Text = " Корректировка страны " + st.ID_strana;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (st == null)
            {
                st = (Strana)stranaBindingSource.List[0];
                DB.Strana.Add(st);
            }
            try
            {
                DB.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Ошибка " + ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
