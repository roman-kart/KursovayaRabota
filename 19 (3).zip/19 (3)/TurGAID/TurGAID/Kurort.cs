namespace TurGAID
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Kurort")]
    public partial class Kurort
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Kurort()
        {
            Tyr = new HashSet<Tyr>();
        }

        [Key]
        public int ID_Kurort { get; set; }

        [Required]
        [StringLength(50)]
        public string Kurort1 { get; set; }

        public int ID_strana { get; set; }

        public virtual Strana Strana { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Tyr> Tyr { get; set; }
    }
}
