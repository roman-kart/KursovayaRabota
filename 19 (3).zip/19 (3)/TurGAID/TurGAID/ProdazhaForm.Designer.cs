﻿
namespace TurGAID
{
    partial class ProdazhaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iD_tyrLabel;
            System.Windows.Forms.Label iD_OtelLabel;
            System.Windows.Forms.Label iD_klientLabel;
            System.Windows.Forms.Label data_nachalo_tyraLabel;
            System.Windows.Forms.Label data_prodazhiLabel;
            System.Windows.Forms.Label stoimostLabel;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            this.prodazhaDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.klientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.tyrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.otelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodazhaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.iD_tyrComboBox = new System.Windows.Forms.ComboBox();
            this.iD_OtelComboBox = new System.Windows.Forms.ComboBox();
            this.SurnameComboBox = new System.Windows.Forms.ComboBox();
            this.data_nachalo_tyraDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.data_prodazhiDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.stoimostTextBox = new System.Windows.Forms.TextBox();
            this.NamecomboBox1 = new System.Windows.Forms.ComboBox();
            this.PatronymiccomboBox2 = new System.Windows.Forms.ComboBox();
            this.ID_Tyr_checkBox1 = new System.Windows.Forms.CheckBox();
            this.Surname_checkBox1 = new System.Windows.Forms.CheckBox();
            this.Name_checkBox1 = new System.Windows.Forms.CheckBox();
            this.Patronymic_checkBox2 = new System.Windows.Forms.CheckBox();
            this.ID_Otel_checkBox3 = new System.Windows.Forms.CheckBox();
            this.Cost_checkBox4 = new System.Windows.Forms.CheckBox();
            this.Data_hachela_tura_checkBox5 = new System.Windows.Forms.CheckBox();
            this.Data_Prodazhi_tura_checkBox6 = new System.Windows.Forms.CheckBox();
            iD_tyrLabel = new System.Windows.Forms.Label();
            iD_OtelLabel = new System.Windows.Forms.Label();
            iD_klientLabel = new System.Windows.Forms.Label();
            data_nachalo_tyraLabel = new System.Windows.Forms.Label();
            data_prodazhiLabel = new System.Windows.Forms.Label();
            stoimostLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.prodazhaDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tyrBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.otelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodazhaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // iD_tyrLabel
            // 
            iD_tyrLabel.AutoSize = true;
            iD_tyrLabel.Location = new System.Drawing.Point(12, 290);
            iD_tyrLabel.Name = "iD_tyrLabel";
            iD_tyrLabel.Size = new System.Drawing.Size(46, 13);
            iD_tyrLabel.TabIndex = 27;
            iD_tyrLabel.Text = "ID тура:";
            // 
            // iD_OtelLabel
            // 
            iD_OtelLabel.AutoSize = true;
            iD_OtelLabel.Location = new System.Drawing.Point(12, 398);
            iD_OtelLabel.Name = "iD_OtelLabel";
            iD_OtelLabel.Size = new System.Drawing.Size(55, 13);
            iD_OtelLabel.TabIndex = 25;
            iD_OtelLabel.Text = "ID Отеля:";
            // 
            // iD_klientLabel
            // 
            iD_klientLabel.AutoSize = true;
            iD_klientLabel.Location = new System.Drawing.Point(12, 317);
            iD_klientLabel.Name = "iD_klientLabel";
            iD_klientLabel.Size = new System.Drawing.Size(59, 13);
            iD_klientLabel.TabIndex = 23;
            iD_klientLabel.Text = "Фамилия:";
            // 
            // data_nachalo_tyraLabel
            // 
            data_nachalo_tyraLabel.AutoSize = true;
            data_nachalo_tyraLabel.Location = new System.Drawing.Point(12, 453);
            data_nachalo_tyraLabel.Name = "data_nachalo_tyraLabel";
            data_nachalo_tyraLabel.Size = new System.Drawing.Size(99, 13);
            data_nachalo_tyraLabel.TabIndex = 18;
            data_nachalo_tyraLabel.Text = "Дата начала тура:";
            // 
            // data_prodazhiLabel
            // 
            data_prodazhiLabel.AutoSize = true;
            data_prodazhiLabel.Location = new System.Drawing.Point(12, 479);
            data_prodazhiLabel.Name = "data_prodazhiLabel";
            data_prodazhiLabel.Size = new System.Drawing.Size(108, 13);
            data_prodazhiLabel.TabIndex = 19;
            data_prodazhiLabel.Text = "Дата продажи тура:";
            // 
            // stoimostLabel
            // 
            stoimostLabel.AutoSize = true;
            stoimostLabel.Location = new System.Drawing.Point(12, 425);
            stoimostLabel.Name = "stoimostLabel";
            stoimostLabel.Size = new System.Drawing.Size(65, 13);
            stoimostLabel.TabIndex = 24;
            stoimostLabel.Text = "Стоимость:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(12, 344);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(32, 13);
            label1.TabIndex = 30;
            label1.Text = "Имя:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(12, 371);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(57, 13);
            label2.TabIndex = 32;
            label2.Text = "Отчество:";
            // 
            // prodazhaDataGridView
            // 
            this.prodazhaDataGridView.AutoGenerateColumns = false;
            this.prodazhaDataGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.prodazhaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.prodazhaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.prodazhaDataGridView.DataSource = this.prodazhaBindingSource;
            this.prodazhaDataGridView.Location = new System.Drawing.Point(-1, 0);
            this.prodazhaDataGridView.Name = "prodazhaDataGridView";
            this.prodazhaDataGridView.Size = new System.Drawing.Size(745, 220);
            this.prodazhaDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID_prodazh";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID Продажи";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ID_klient";
            this.dataGridViewTextBoxColumn2.DataSource = this.klientBindingSource;
            this.dataGridViewTextBoxColumn2.DisplayMember = "Familia";
            this.dataGridViewTextBoxColumn2.HeaderText = "ID Клиента";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn2.ValueMember = "ID_klient";
            // 
            // klientBindingSource
            // 
            this.klientBindingSource.DataSource = typeof(TurGAID.Klient);
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ID_tyr";
            this.dataGridViewTextBoxColumn3.DataSource = this.tyrBindingSource;
            this.dataGridViewTextBoxColumn3.DisplayMember = "Tyr1";
            this.dataGridViewTextBoxColumn3.HeaderText = "ID Тура";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn3.ValueMember = "ID_tyr";
            // 
            // tyrBindingSource
            // 
            this.tyrBindingSource.DataSource = typeof(TurGAID.Tyr);
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ID_Otel";
            this.dataGridViewTextBoxColumn7.DataSource = this.otelBindingSource;
            this.dataGridViewTextBoxColumn7.DisplayMember = "Klass_Otel";
            this.dataGridViewTextBoxColumn7.HeaderText = "ID Отеля";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn7.ValueMember = "ID_Otel";
            // 
            // otelBindingSource
            // 
            this.otelBindingSource.DataSource = typeof(TurGAID.Otel);
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Stoimost";
            this.dataGridViewTextBoxColumn4.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Data_prodazhi";
            this.dataGridViewTextBoxColumn5.HeaderText = "Дата продажи";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Data_nachalo_tyra";
            this.dataGridViewTextBoxColumn6.HeaderText = "Дата начала тура";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // prodazhaBindingSource
            // 
            this.prodazhaBindingSource.DataSource = typeof(TurGAID.Prodazha);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button5.Location = new System.Drawing.Point(496, 226);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(115, 46);
            this.button5.TabIndex = 16;
            this.button5.Text = "Выйти из приложения";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.LightGreen;
            this.button4.Location = new System.Drawing.Point(617, 226);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(115, 46);
            this.button4.TabIndex = 15;
            this.button4.Text = "Вернуться в главное меню";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button3.Location = new System.Drawing.Point(254, 226);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(115, 46);
            this.button3.TabIndex = 14;
            this.button3.Text = "Удалить";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.Location = new System.Drawing.Point(133, 226);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 46);
            this.button2.TabIndex = 13;
            this.button2.Text = "Изменить";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(12, 226);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 46);
            this.button1.TabIndex = 12;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.LightGreen;
            this.button6.Location = new System.Drawing.Point(12, 509);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(342, 46);
            this.button6.TabIndex = 17;
            this.button6.Text = "Найти";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // iD_tyrComboBox
            // 
            this.iD_tyrComboBox.DataSource = this.tyrBindingSource;
            this.iD_tyrComboBox.DisplayMember = "Tyr1";
            this.iD_tyrComboBox.FormattingEnabled = true;
            this.iD_tyrComboBox.Location = new System.Drawing.Point(133, 286);
            this.iD_tyrComboBox.Name = "iD_tyrComboBox";
            this.iD_tyrComboBox.Size = new System.Drawing.Size(200, 21);
            this.iD_tyrComboBox.TabIndex = 29;
            this.iD_tyrComboBox.ValueMember = "ID_tyr";
            // 
            // iD_OtelComboBox
            // 
            this.iD_OtelComboBox.DataSource = this.otelBindingSource;
            this.iD_OtelComboBox.DisplayMember = "Klass_Otel";
            this.iD_OtelComboBox.FormattingEnabled = true;
            this.iD_OtelComboBox.Location = new System.Drawing.Point(131, 395);
            this.iD_OtelComboBox.Name = "iD_OtelComboBox";
            this.iD_OtelComboBox.Size = new System.Drawing.Size(200, 21);
            this.iD_OtelComboBox.TabIndex = 28;
            this.iD_OtelComboBox.ValueMember = "ID_Otel";
            // 
            // SurnameComboBox
            // 
            this.SurnameComboBox.DataSource = this.klientBindingSource;
            this.SurnameComboBox.DisplayMember = "Familia";
            this.SurnameComboBox.FormattingEnabled = true;
            this.SurnameComboBox.Location = new System.Drawing.Point(131, 314);
            this.SurnameComboBox.Name = "SurnameComboBox";
            this.SurnameComboBox.Size = new System.Drawing.Size(200, 21);
            this.SurnameComboBox.TabIndex = 26;
            this.SurnameComboBox.ValueMember = "ID_klient";
            // 
            // data_nachalo_tyraDateTimePicker
            // 
            this.data_nachalo_tyraDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.prodazhaBindingSource, "Data_nachalo_tyra", true));
            this.data_nachalo_tyraDateTimePicker.Location = new System.Drawing.Point(131, 449);
            this.data_nachalo_tyraDateTimePicker.Name = "data_nachalo_tyraDateTimePicker";
            this.data_nachalo_tyraDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.data_nachalo_tyraDateTimePicker.TabIndex = 21;
            // 
            // data_prodazhiDateTimePicker
            // 
            this.data_prodazhiDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.prodazhaBindingSource, "Data_prodazhi", true));
            this.data_prodazhiDateTimePicker.Location = new System.Drawing.Point(131, 475);
            this.data_prodazhiDateTimePicker.Name = "data_prodazhiDateTimePicker";
            this.data_prodazhiDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.data_prodazhiDateTimePicker.TabIndex = 22;
            // 
            // stoimostTextBox
            // 
            this.stoimostTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.prodazhaBindingSource, "Stoimost", true));
            this.stoimostTextBox.Location = new System.Drawing.Point(131, 422);
            this.stoimostTextBox.Name = "stoimostTextBox";
            this.stoimostTextBox.Size = new System.Drawing.Size(200, 20);
            this.stoimostTextBox.TabIndex = 20;
            // 
            // NamecomboBox1
            // 
            this.NamecomboBox1.DataSource = this.klientBindingSource;
            this.NamecomboBox1.DisplayMember = "Name";
            this.NamecomboBox1.FormattingEnabled = true;
            this.NamecomboBox1.Location = new System.Drawing.Point(131, 341);
            this.NamecomboBox1.Name = "NamecomboBox1";
            this.NamecomboBox1.Size = new System.Drawing.Size(200, 21);
            this.NamecomboBox1.TabIndex = 31;
            this.NamecomboBox1.ValueMember = "ID_klient";
            // 
            // PatronymiccomboBox2
            // 
            this.PatronymiccomboBox2.DataSource = this.klientBindingSource;
            this.PatronymiccomboBox2.DisplayMember = "Otchestvo";
            this.PatronymiccomboBox2.FormattingEnabled = true;
            this.PatronymiccomboBox2.Location = new System.Drawing.Point(131, 368);
            this.PatronymiccomboBox2.Name = "PatronymiccomboBox2";
            this.PatronymiccomboBox2.Size = new System.Drawing.Size(200, 21);
            this.PatronymiccomboBox2.TabIndex = 33;
            this.PatronymiccomboBox2.ValueMember = "ID_klient";
            // 
            // ID_Tyr_checkBox1
            // 
            this.ID_Tyr_checkBox1.AutoSize = true;
            this.ID_Tyr_checkBox1.Location = new System.Drawing.Point(337, 290);
            this.ID_Tyr_checkBox1.Name = "ID_Tyr_checkBox1";
            this.ID_Tyr_checkBox1.Size = new System.Drawing.Size(15, 14);
            this.ID_Tyr_checkBox1.TabIndex = 34;
            this.ID_Tyr_checkBox1.UseVisualStyleBackColor = true;
            // 
            // Surname_checkBox1
            // 
            this.Surname_checkBox1.AutoSize = true;
            this.Surname_checkBox1.Location = new System.Drawing.Point(337, 316);
            this.Surname_checkBox1.Name = "Surname_checkBox1";
            this.Surname_checkBox1.Size = new System.Drawing.Size(15, 14);
            this.Surname_checkBox1.TabIndex = 35;
            this.Surname_checkBox1.UseVisualStyleBackColor = true;
            // 
            // Name_checkBox1
            // 
            this.Name_checkBox1.AutoSize = true;
            this.Name_checkBox1.Location = new System.Drawing.Point(337, 344);
            this.Name_checkBox1.Name = "Name_checkBox1";
            this.Name_checkBox1.Size = new System.Drawing.Size(15, 14);
            this.Name_checkBox1.TabIndex = 36;
            this.Name_checkBox1.UseVisualStyleBackColor = true;
            // 
            // Patronymic_checkBox2
            // 
            this.Patronymic_checkBox2.AutoSize = true;
            this.Patronymic_checkBox2.Location = new System.Drawing.Point(337, 371);
            this.Patronymic_checkBox2.Name = "Patronymic_checkBox2";
            this.Patronymic_checkBox2.Size = new System.Drawing.Size(15, 14);
            this.Patronymic_checkBox2.TabIndex = 37;
            this.Patronymic_checkBox2.UseVisualStyleBackColor = true;
            // 
            // ID_Otel_checkBox3
            // 
            this.ID_Otel_checkBox3.AutoSize = true;
            this.ID_Otel_checkBox3.Location = new System.Drawing.Point(337, 398);
            this.ID_Otel_checkBox3.Name = "ID_Otel_checkBox3";
            this.ID_Otel_checkBox3.Size = new System.Drawing.Size(15, 14);
            this.ID_Otel_checkBox3.TabIndex = 38;
            this.ID_Otel_checkBox3.UseVisualStyleBackColor = true;
            // 
            // Cost_checkBox4
            // 
            this.Cost_checkBox4.AutoSize = true;
            this.Cost_checkBox4.Location = new System.Drawing.Point(337, 425);
            this.Cost_checkBox4.Name = "Cost_checkBox4";
            this.Cost_checkBox4.Size = new System.Drawing.Size(15, 14);
            this.Cost_checkBox4.TabIndex = 39;
            this.Cost_checkBox4.UseVisualStyleBackColor = true;
            // 
            // Data_hachela_tura_checkBox5
            // 
            this.Data_hachela_tura_checkBox5.AutoSize = true;
            this.Data_hachela_tura_checkBox5.Location = new System.Drawing.Point(337, 453);
            this.Data_hachela_tura_checkBox5.Name = "Data_hachela_tura_checkBox5";
            this.Data_hachela_tura_checkBox5.Size = new System.Drawing.Size(15, 14);
            this.Data_hachela_tura_checkBox5.TabIndex = 40;
            this.Data_hachela_tura_checkBox5.UseVisualStyleBackColor = true;
            // 
            // Data_Prodazhi_tura_checkBox6
            // 
            this.Data_Prodazhi_tura_checkBox6.AutoSize = true;
            this.Data_Prodazhi_tura_checkBox6.Location = new System.Drawing.Point(337, 479);
            this.Data_Prodazhi_tura_checkBox6.Name = "Data_Prodazhi_tura_checkBox6";
            this.Data_Prodazhi_tura_checkBox6.Size = new System.Drawing.Size(15, 14);
            this.Data_Prodazhi_tura_checkBox6.TabIndex = 41;
            this.Data_Prodazhi_tura_checkBox6.UseVisualStyleBackColor = true;
            // 
            // ProdazhaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(744, 567);
            this.Controls.Add(this.Data_Prodazhi_tura_checkBox6);
            this.Controls.Add(this.Data_hachela_tura_checkBox5);
            this.Controls.Add(this.Cost_checkBox4);
            this.Controls.Add(this.ID_Otel_checkBox3);
            this.Controls.Add(this.Patronymic_checkBox2);
            this.Controls.Add(this.Name_checkBox1);
            this.Controls.Add(this.Surname_checkBox1);
            this.Controls.Add(this.ID_Tyr_checkBox1);
            this.Controls.Add(label2);
            this.Controls.Add(this.PatronymiccomboBox2);
            this.Controls.Add(label1);
            this.Controls.Add(this.NamecomboBox1);
            this.Controls.Add(iD_tyrLabel);
            this.Controls.Add(this.iD_tyrComboBox);
            this.Controls.Add(iD_OtelLabel);
            this.Controls.Add(this.iD_OtelComboBox);
            this.Controls.Add(iD_klientLabel);
            this.Controls.Add(this.SurnameComboBox);
            this.Controls.Add(data_nachalo_tyraLabel);
            this.Controls.Add(this.data_nachalo_tyraDateTimePicker);
            this.Controls.Add(data_prodazhiLabel);
            this.Controls.Add(this.data_prodazhiDateTimePicker);
            this.Controls.Add(stoimostLabel);
            this.Controls.Add(this.stoimostTextBox);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.prodazhaDataGridView);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(760, 606);
            this.MinimumSize = new System.Drawing.Size(760, 606);
            this.Name = "ProdazhaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Продажи";
            this.Load += new System.EventHandler(this.ProdazhaForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.prodazhaDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tyrBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.otelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodazhaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource prodazhaBindingSource;
        private System.Windows.Forms.DataGridView prodazhaDataGridView;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource klientBindingSource;
        private System.Windows.Forms.BindingSource tyrBindingSource;
        private System.Windows.Forms.BindingSource otelBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox iD_tyrComboBox;
        private System.Windows.Forms.ComboBox iD_OtelComboBox;
        private System.Windows.Forms.ComboBox SurnameComboBox;
        private System.Windows.Forms.DateTimePicker data_nachalo_tyraDateTimePicker;
        private System.Windows.Forms.DateTimePicker data_prodazhiDateTimePicker;
        private System.Windows.Forms.TextBox stoimostTextBox;
        private System.Windows.Forms.ComboBox NamecomboBox1;
        private System.Windows.Forms.ComboBox PatronymiccomboBox2;
        private System.Windows.Forms.CheckBox ID_Tyr_checkBox1;
        private System.Windows.Forms.CheckBox Surname_checkBox1;
        private System.Windows.Forms.CheckBox Name_checkBox1;
        private System.Windows.Forms.CheckBox Patronymic_checkBox2;
        private System.Windows.Forms.CheckBox ID_Otel_checkBox3;
        private System.Windows.Forms.CheckBox Cost_checkBox4;
        private System.Windows.Forms.CheckBox Data_hachela_tura_checkBox5;
        private System.Windows.Forms.CheckBox Data_Prodazhi_tura_checkBox6;
    }
}