﻿
namespace TurGAID
{
    partial class CurretStranaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iD_stranaLabel;
            System.Windows.Forms.Label moneyLabel;
            System.Windows.Forms.Label stolitsyaLabel;
            System.Windows.Forms.Label strana1Label;
            System.Windows.Forms.Label yazikLabel;
            this.iD_stranaTextBox = new System.Windows.Forms.TextBox();
            this.moneyTextBox = new System.Windows.Forms.TextBox();
            this.stolitsyaTextBox = new System.Windows.Forms.TextBox();
            this.strana1TextBox = new System.Windows.Forms.TextBox();
            this.yazikTextBox = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.stranaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            iD_stranaLabel = new System.Windows.Forms.Label();
            moneyLabel = new System.Windows.Forms.Label();
            stolitsyaLabel = new System.Windows.Forms.Label();
            strana1Label = new System.Windows.Forms.Label();
            yazikLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.stranaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // iD_stranaLabel
            // 
            iD_stranaLabel.AutoSize = true;
            iD_stranaLabel.Location = new System.Drawing.Point(31, 163);
            iD_stranaLabel.Name = "iD_stranaLabel";
            iD_stranaLabel.Size = new System.Drawing.Size(21, 13);
            iD_stranaLabel.TabIndex = 1;
            iD_stranaLabel.Text = "ID:";
            iD_stranaLabel.Visible = false;
            // 
            // moneyLabel
            // 
            moneyLabel.AutoSize = true;
            moneyLabel.Location = new System.Drawing.Point(31, 43);
            moneyLabel.Name = "moneyLabel";
            moneyLabel.Size = new System.Drawing.Size(108, 13);
            moneyLabel.TabIndex = 3;
            moneyLabel.Text = "Денежная единица:";
            // 
            // stolitsyaLabel
            // 
            stolitsyaLabel.AutoSize = true;
            stolitsyaLabel.Location = new System.Drawing.Point(31, 69);
            stolitsyaLabel.Name = "stolitsyaLabel";
            stolitsyaLabel.Size = new System.Drawing.Size(52, 13);
            stolitsyaLabel.TabIndex = 5;
            stolitsyaLabel.Text = "Столица:";
            // 
            // strana1Label
            // 
            strana1Label.AutoSize = true;
            strana1Label.Location = new System.Drawing.Point(31, 17);
            strana1Label.Name = "strana1Label";
            strana1Label.Size = new System.Drawing.Size(46, 13);
            strana1Label.TabIndex = 7;
            strana1Label.Text = "Страна:";
            // 
            // yazikLabel
            // 
            yazikLabel.AutoSize = true;
            yazikLabel.Location = new System.Drawing.Point(31, 95);
            yazikLabel.Name = "yazikLabel";
            yazikLabel.Size = new System.Drawing.Size(38, 13);
            yazikLabel.TabIndex = 9;
            yazikLabel.Text = "Язык:";
            // 
            // iD_stranaTextBox
            // 
            this.iD_stranaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stranaBindingSource, "ID_strana", true));
            this.iD_stranaTextBox.Location = new System.Drawing.Point(164, 160);
            this.iD_stranaTextBox.Name = "iD_stranaTextBox";
            this.iD_stranaTextBox.Size = new System.Drawing.Size(100, 20);
            this.iD_stranaTextBox.TabIndex = 2;
            this.iD_stranaTextBox.Visible = false;
            // 
            // moneyTextBox
            // 
            this.moneyTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stranaBindingSource, "Money", true));
            this.moneyTextBox.Location = new System.Drawing.Point(164, 40);
            this.moneyTextBox.Name = "moneyTextBox";
            this.moneyTextBox.Size = new System.Drawing.Size(100, 20);
            this.moneyTextBox.TabIndex = 2;
            // 
            // stolitsyaTextBox
            // 
            this.stolitsyaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stranaBindingSource, "Stolitsya", true));
            this.stolitsyaTextBox.Location = new System.Drawing.Point(164, 66);
            this.stolitsyaTextBox.Name = "stolitsyaTextBox";
            this.stolitsyaTextBox.Size = new System.Drawing.Size(100, 20);
            this.stolitsyaTextBox.TabIndex = 3;
            // 
            // strana1TextBox
            // 
            this.strana1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stranaBindingSource, "Strana1", true));
            this.strana1TextBox.Location = new System.Drawing.Point(164, 14);
            this.strana1TextBox.Name = "strana1TextBox";
            this.strana1TextBox.Size = new System.Drawing.Size(100, 20);
            this.strana1TextBox.TabIndex = 1;
            // 
            // yazikTextBox
            // 
            this.yazikTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stranaBindingSource, "Yazik", true));
            this.yazikTextBox.Location = new System.Drawing.Point(164, 92);
            this.yazikTextBox.Name = "yazikTextBox";
            this.yazikTextBox.Size = new System.Drawing.Size(100, 20);
            this.yazikTextBox.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(192, 126);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 46);
            this.button2.TabIndex = 6;
            this.button2.Text = "Вернуться";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(19, 126);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 46);
            this.button1.TabIndex = 5;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // stranaBindingSource
            // 
            this.stranaBindingSource.DataSource = typeof(TurGAID.Strana);
            // 
            // CurretStranaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(321, 192);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(iD_stranaLabel);
            this.Controls.Add(this.iD_stranaTextBox);
            this.Controls.Add(moneyLabel);
            this.Controls.Add(this.moneyTextBox);
            this.Controls.Add(stolitsyaLabel);
            this.Controls.Add(this.stolitsyaTextBox);
            this.Controls.Add(strana1Label);
            this.Controls.Add(this.strana1TextBox);
            this.Controls.Add(yazikLabel);
            this.Controls.Add(this.yazikTextBox);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(337, 231);
            this.MinimumSize = new System.Drawing.Size(337, 231);
            this.Name = "CurretStranaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Текущая Страна";
            this.Load += new System.EventHandler(this.CurretStranaForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stranaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource stranaBindingSource;
        private System.Windows.Forms.TextBox iD_stranaTextBox;
        private System.Windows.Forms.TextBox moneyTextBox;
        private System.Windows.Forms.TextBox stolitsyaTextBox;
        private System.Windows.Forms.TextBox strana1TextBox;
        private System.Windows.Forms.TextBox yazikTextBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}