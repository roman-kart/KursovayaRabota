﻿
namespace TurGAID
{
    partial class CurrentTyrForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iD_tyrLabel;
            System.Windows.Forms.Label timeLabel;
            System.Windows.Forms.Label tyr1Label;
            System.Windows.Forms.Label iD_KurortLabel1;
            this.iD_tyrTextBox = new System.Windows.Forms.TextBox();
            this.tyrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.timeTextBox = new System.Windows.Forms.TextBox();
            this.tyr1TextBox = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.iD_KurortComboBox = new System.Windows.Forms.ComboBox();
            this.kurortBindingSource = new System.Windows.Forms.BindingSource(this.components);
            iD_tyrLabel = new System.Windows.Forms.Label();
            timeLabel = new System.Windows.Forms.Label();
            tyr1Label = new System.Windows.Forms.Label();
            iD_KurortLabel1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tyrBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurortBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // iD_tyrLabel
            // 
            iD_tyrLabel.AutoSize = true;
            iD_tyrLabel.Location = new System.Drawing.Point(40, 130);
            iD_tyrLabel.Name = "iD_tyrLabel";
            iD_tyrLabel.Size = new System.Drawing.Size(48, 13);
            iD_tyrLabel.TabIndex = 3;
            iD_tyrLabel.Text = "ID Тура:";
            iD_tyrLabel.Visible = false;
            // 
            // timeLabel
            // 
            timeLabel.AutoSize = true;
            timeLabel.Location = new System.Drawing.Point(40, 39);
            timeLabel.Name = "timeLabel";
            timeLabel.Size = new System.Drawing.Size(43, 13);
            timeLabel.TabIndex = 5;
            timeLabel.Text = "Время:";
            // 
            // tyr1Label
            // 
            tyr1Label.AutoSize = true;
            tyr1Label.Location = new System.Drawing.Point(40, 65);
            tyr1Label.Name = "tyr1Label";
            tyr1Label.Size = new System.Drawing.Size(85, 13);
            tyr1Label.TabIndex = 7;
            tyr1Label.Text = "Название тура:";
            // 
            // iD_KurortLabel1
            // 
            iD_KurortLabel1.AutoSize = true;
            iD_KurortLabel1.Location = new System.Drawing.Point(40, 12);
            iD_KurortLabel1.Name = "iD_KurortLabel1";
            iD_KurortLabel1.Size = new System.Drawing.Size(52, 13);
            iD_KurortLabel1.TabIndex = 10;
            iD_KurortLabel1.Text = "ID Kurort:";
            // 
            // iD_tyrTextBox
            // 
            this.iD_tyrTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tyrBindingSource, "ID_tyr", true));
            this.iD_tyrTextBox.Location = new System.Drawing.Point(149, 127);
            this.iD_tyrTextBox.Name = "iD_tyrTextBox";
            this.iD_tyrTextBox.Size = new System.Drawing.Size(200, 20);
            this.iD_tyrTextBox.TabIndex = 1;
            this.iD_tyrTextBox.Visible = false;
            // 
            // tyrBindingSource
            // 
            this.tyrBindingSource.DataSource = typeof(TurGAID.Tyr);
            // 
            // timeTextBox
            // 
            this.timeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tyrBindingSource, "Time", true));
            this.timeTextBox.Location = new System.Drawing.Point(149, 36);
            this.timeTextBox.Name = "timeTextBox";
            this.timeTextBox.Size = new System.Drawing.Size(200, 20);
            this.timeTextBox.TabIndex = 2;
            // 
            // tyr1TextBox
            // 
            this.tyr1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tyrBindingSource, "Tyr1", true));
            this.tyr1TextBox.Location = new System.Drawing.Point(149, 62);
            this.tyr1TextBox.Name = "tyr1TextBox";
            this.tyr1TextBox.Size = new System.Drawing.Size(200, 20);
            this.tyr1TextBox.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(204, 95);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 46);
            this.button2.TabIndex = 5;
            this.button2.Text = "Вернуться";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(53, 95);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 46);
            this.button1.TabIndex = 4;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // iD_KurortComboBox
            // 
            this.iD_KurortComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tyrBindingSource, "ID_Kurort", true));
            this.iD_KurortComboBox.DataSource = this.kurortBindingSource;
            this.iD_KurortComboBox.DisplayMember = "Kurort1";
            this.iD_KurortComboBox.FormattingEnabled = true;
            this.iD_KurortComboBox.Location = new System.Drawing.Point(149, 9);
            this.iD_KurortComboBox.Name = "iD_KurortComboBox";
            this.iD_KurortComboBox.Size = new System.Drawing.Size(200, 21);
            this.iD_KurortComboBox.TabIndex = 11;
            this.iD_KurortComboBox.ValueMember = "ID_Kurort";
            // 
            // kurortBindingSource
            // 
            this.kurortBindingSource.DataSource = typeof(TurGAID.Kurort);
            // 
            // CurrentTyrForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(371, 167);
            this.Controls.Add(iD_KurortLabel1);
            this.Controls.Add(this.iD_KurortComboBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(iD_tyrLabel);
            this.Controls.Add(this.iD_tyrTextBox);
            this.Controls.Add(timeLabel);
            this.Controls.Add(this.timeTextBox);
            this.Controls.Add(tyr1Label);
            this.Controls.Add(this.tyr1TextBox);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(387, 206);
            this.MinimumSize = new System.Drawing.Size(387, 206);
            this.Name = "CurrentTyrForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Текущий Тур";
            this.Load += new System.EventHandler(this.CurrentTyrForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tyrBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurortBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource tyrBindingSource;
        private System.Windows.Forms.TextBox iD_tyrTextBox;
        private System.Windows.Forms.TextBox timeTextBox;
        private System.Windows.Forms.TextBox tyr1TextBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox iD_KurortComboBox;
        private System.Windows.Forms.BindingSource kurortBindingSource;
    }
}