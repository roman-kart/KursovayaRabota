﻿
namespace TurGAID
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Clients = new System.Windows.Forms.Button();
            this.button_Country = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button_Otel = new System.Windows.Forms.Button();
            this.button_Kurort = new System.Windows.Forms.Button();
            this.button_Prodazha = new System.Windows.Forms.Button();
            this.button_Tyr = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_Clients
            // 
            this.button_Clients.BackColor = System.Drawing.Color.LightCyan;
            this.button_Clients.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Clients.Location = new System.Drawing.Point(12, 85);
            this.button_Clients.Name = "button_Clients";
            this.button_Clients.Size = new System.Drawing.Size(140, 38);
            this.button_Clients.TabIndex = 0;
            this.button_Clients.Text = "Клиент";
            this.button_Clients.UseVisualStyleBackColor = false;
            this.button_Clients.Click += new System.EventHandler(this.button2_Click);
            // 
            // button_Country
            // 
            this.button_Country.BackColor = System.Drawing.Color.LightCyan;
            this.button_Country.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Country.Location = new System.Drawing.Point(12, 139);
            this.button_Country.Name = "button_Country";
            this.button_Country.Size = new System.Drawing.Size(140, 38);
            this.button_Country.TabIndex = 1;
            this.button_Country.Text = "Страна";
            this.button_Country.UseVisualStyleBackColor = false;
            this.button_Country.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(158, 85);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(594, 353);
            this.dataGridView1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.label1.Location = new System.Drawing.Point(7, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 26);
            this.label1.TabIndex = 3;
            this.label1.Text = "Таблицы";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightSteelBlue;
            this.button3.Location = new System.Drawing.Point(28, 413);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(93, 24);
            this.button3.TabIndex = 4;
            this.button3.Text = "Редактировать";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.NavajoWhite;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.label2.Location = new System.Drawing.Point(512, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(216, 28);
            this.label2.TabIndex = 5;
            this.label2.Text = "Туристический гид";
            // 
            // button_Otel
            // 
            this.button_Otel.BackColor = System.Drawing.Color.LightCyan;
            this.button_Otel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Otel.Location = new System.Drawing.Point(12, 194);
            this.button_Otel.Name = "button_Otel";
            this.button_Otel.Size = new System.Drawing.Size(140, 38);
            this.button_Otel.TabIndex = 6;
            this.button_Otel.Text = "Отель";
            this.button_Otel.UseVisualStyleBackColor = false;
            this.button_Otel.Click += new System.EventHandler(this.button_Otel_Click);
            // 
            // button_Kurort
            // 
            this.button_Kurort.BackColor = System.Drawing.Color.LightCyan;
            this.button_Kurort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Kurort.Location = new System.Drawing.Point(12, 247);
            this.button_Kurort.Name = "button_Kurort";
            this.button_Kurort.Size = new System.Drawing.Size(140, 38);
            this.button_Kurort.TabIndex = 7;
            this.button_Kurort.Text = "Курорт";
            this.button_Kurort.UseVisualStyleBackColor = false;
            this.button_Kurort.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button_Prodazha
            // 
            this.button_Prodazha.BackColor = System.Drawing.Color.LightCyan;
            this.button_Prodazha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Prodazha.Location = new System.Drawing.Point(12, 301);
            this.button_Prodazha.Name = "button_Prodazha";
            this.button_Prodazha.Size = new System.Drawing.Size(140, 38);
            this.button_Prodazha.TabIndex = 8;
            this.button_Prodazha.Text = "Продажа";
            this.button_Prodazha.UseVisualStyleBackColor = false;
            this.button_Prodazha.Click += new System.EventHandler(this.button_Prodazha_Click);
            // 
            // button_Tyr
            // 
            this.button_Tyr.BackColor = System.Drawing.Color.LightCyan;
            this.button_Tyr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Tyr.Location = new System.Drawing.Point(12, 355);
            this.button_Tyr.Name = "button_Tyr";
            this.button_Tyr.Size = new System.Drawing.Size(140, 38);
            this.button_Tyr.TabIndex = 9;
            this.button_Tyr.Text = "Тур";
            this.button_Tyr.UseVisualStyleBackColor = false;
            this.button_Tyr.Click += new System.EventHandler(this.button_Tyr_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(764, 450);
            this.Controls.Add(this.button_Tyr);
            this.Controls.Add(this.button_Prodazha);
            this.Controls.Add(this.button_Kurort);
            this.Controls.Add(this.button_Otel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button_Country);
            this.Controls.Add(this.button_Clients);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(780, 489);
            this.MinimumSize = new System.Drawing.Size(780, 489);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Главное меню";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_Clients;
        private System.Windows.Forms.Button button_Country;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_Otel;
        private System.Windows.Forms.Button button_Kurort;
        private System.Windows.Forms.Button button_Prodazha;
        private System.Windows.Forms.Button button_Tyr;
    }
}

