﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class MainForm : Form
    {
        Model1 DB = new Model1();
        public MainForm()
        {
            InitializeComponent();
        }
        int currentForm;
        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = DB.Klient.ToList();
            this.dataGridView1.Columns.Remove("Prodazha");
            currentForm = 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = DB.Strana.ToList();
            this.dataGridView1.Columns.Remove("Kurort");
            this.dataGridView1.Columns.Remove("Karta");
            currentForm = 2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            switch (currentForm)
            {
                case 1:
                    KlientForm frm1 = new KlientForm();
                    this.Hide();
                    frm1.Show();
                    break;
                case 2:
                    StranaForm frm2 = new StranaForm();
                    this.Hide();
                    frm2.Show();
                    break;
                case 3:
                    OtelForm frm3 = new OtelForm();
                    this.Hide();
                    frm3.Show();
                    break;
                case 4:
                    KurortForm frm4 = new KurortForm();
                    this.Hide();
                    frm4.Show();
                    break;
                case 5:
                    ProdazhaForm frm5 = new ProdazhaForm();
                    this.Hide();
                    frm5.Show();
                    break;
                case 6:
                    TyrForm frm6 = new TyrForm();
                    this.Hide();
                    frm6.Show();
                    break;
            }
        }

        private void button_Otel_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = DB.Otel.ToList();
            this.dataGridView1.Columns.Remove("Prodazha");
            currentForm = 3;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            dataGridView1.DataSource = DB.Kurort.ToList();
            this.dataGridView1.Columns.Remove("Strana");
            this.dataGridView1.Columns.Remove("Tyr");
            currentForm = 4;
        }

        private void button_Prodazha_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = DB.Prodazha.ToList();
            this.dataGridView1.Columns.Remove("Tyr");
            this.dataGridView1.Columns.Remove("Otel");
            this.dataGridView1.Columns.Remove("Klient");
            currentForm = 5;
        }

        private void button_Tyr_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = DB.Tyr.ToList();
            this.dataGridView1.Columns.Remove("Prodazha");
            this.dataGridView1.Columns.Remove("Kurort");
            currentForm = 6;
        }
    }
}
