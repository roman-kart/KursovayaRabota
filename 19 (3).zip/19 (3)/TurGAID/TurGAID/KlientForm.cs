﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class KlientForm : Form
    {
        Model1 DB = new Model1();
        public KlientForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CurretKlientForm frm = new CurretKlientForm();
            frm.DB = DB;
            frm.kl = null;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                //klientBindingSource.DataSource = null;
                klientBindingSource.DataSource = DB.Klient.ToList();
            }
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Klient kl = (Klient)klientBindingSource.Current;
            CurretKlientForm frm = new CurretKlientForm();
            frm.DB = DB;
            frm.kl = kl;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                //klientBindingSource.DataSource = null;
                klientBindingSource.DataSource = DB.Klient.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Klient kl = (Klient)klientBindingSource.Current;
            DialogResult dr = MessageBox.Show(" Удалить " +
              kl.ID_klient + "?", " Удаление ",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                if (kl.Prodazha.Count == 0)
                {
                    DB.Klient.Remove(kl);
                }
                else
                {
                    MessageBox.Show("Для удаления клиента необходимо удалить связанные с клиентом продажи!");
                }
                try
                {
                    DB.SaveChanges();
                    klientBindingSource.DataSource = DB.Klient.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.InnerException.InnerException.Message);
                }
            }
        }

        private void KlientForm_Load(object sender, EventArgs e)
        {
            klientBindingSource.DataSource = DB.Klient.ToList();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainForm frm = new MainForm();
            this.Hide();
            frm.Show();
        }

        private void search_button6_Click(object sender, EventArgs e)
        {
            
            try
            {
                var klienti = from klient in DB.Klient.ToList()
                         where this.isCorrect(klient)
                         select klient;
                this.klientBindingSource.DataSource = klienti.ToList();
            }
            catch (IndexOutOfRangeException ex)
            {
                MessageBox.Show("Заполните параметры для поиска.");
            }
            catch (ArgumentOutOfRangeException ex)
            {
                MessageBox.Show("Заполните параметры для поиска.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неизвестная ошибка! Обратитесь к системному администратору.");
            }
        }
        private bool isCorrect(TurGAID.Klient klient)
        {
            bool isChecked = false;
            bool isCorrect = true;
            if (Surname_checkBox1.Checked && (SurnameComboBox.Text == klient.Familia))
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (Name_checkBox1.Checked && (NamecomboBox1.Text == klient.Name))
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (Patronymic_checkBox2.Checked && (PatronymiccomboBox2.Text == klient.Otchestvo))
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (bithday_checkBox4.Checked && (birthday_dateTimePicker1.Value == klient.Data_rozhdenia))
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (adress_checkBox1.Checked && (address_textBox1.Text == klient.Adres))
            {
                isCorrect &= true;
                isChecked = true;
            }

            return isCorrect && isChecked;
        }

        private void KlientForm_FormClosing(object sender, FormClosingEventArgs e)
        {

        }
    }
}
