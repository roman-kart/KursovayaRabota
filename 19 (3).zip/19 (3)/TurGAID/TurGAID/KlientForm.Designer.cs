﻿
namespace TurGAID
{
    partial class KlientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label iD_klientLabel;
            System.Windows.Forms.Label stoimostLabel;
            System.Windows.Forms.Label label3;
            this.klientDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.klientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.Patronymic_checkBox2 = new System.Windows.Forms.CheckBox();
            this.Name_checkBox1 = new System.Windows.Forms.CheckBox();
            this.Surname_checkBox1 = new System.Windows.Forms.CheckBox();
            this.PatronymiccomboBox2 = new System.Windows.Forms.ComboBox();
            this.NamecomboBox1 = new System.Windows.Forms.ComboBox();
            this.SurnameComboBox = new System.Windows.Forms.ComboBox();
            this.bithday_checkBox4 = new System.Windows.Forms.CheckBox();
            this.adress_checkBox1 = new System.Windows.Forms.CheckBox();
            this.address_textBox1 = new System.Windows.Forms.TextBox();
            this.birthday_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.search_button6 = new System.Windows.Forms.Button();
            label2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            iD_klientLabel = new System.Windows.Forms.Label();
            stoimostLabel = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.klientDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(12, 486);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(57, 13);
            label2.TabIndex = 42;
            label2.Text = "Отчество:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(12, 459);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(32, 13);
            label1.TabIndex = 40;
            label1.Text = "Имя:";
            // 
            // iD_klientLabel
            // 
            iD_klientLabel.AutoSize = true;
            iD_klientLabel.Location = new System.Drawing.Point(12, 432);
            iD_klientLabel.Name = "iD_klientLabel";
            iD_klientLabel.Size = new System.Drawing.Size(59, 13);
            iD_klientLabel.TabIndex = 38;
            iD_klientLabel.Text = "Фамилия:";
            // 
            // stoimostLabel
            // 
            stoimostLabel.AutoSize = true;
            stoimostLabel.Location = new System.Drawing.Point(14, 513);
            stoimostLabel.Name = "stoimostLabel";
            stoimostLabel.Size = new System.Drawing.Size(89, 13);
            stoimostLabel.TabIndex = 48;
            stoimostLabel.Text = "Дата рождения:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(14, 539);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(41, 13);
            label3.TabIndex = 51;
            label3.Text = "Адрес:";
            // 
            // klientDataGridView
            // 
            this.klientDataGridView.AutoGenerateColumns = false;
            this.klientDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.klientDataGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.klientDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.klientDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.klientDataGridView.DataSource = this.klientBindingSource;
            this.klientDataGridView.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.klientDataGridView.Location = new System.Drawing.Point(1, 0);
            this.klientDataGridView.Name = "klientDataGridView";
            this.klientDataGridView.Size = new System.Drawing.Size(744, 368);
            this.klientDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID_klient";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID Клиента";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Familia";
            this.dataGridViewTextBoxColumn2.HeaderText = "Фамилия";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn3.HeaderText = "Имя";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Otchestvo";
            this.dataGridViewTextBoxColumn4.HeaderText = "Отчество";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Data_rozhdenia";
            this.dataGridViewTextBoxColumn5.HeaderText = "Дата рождения";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Adres";
            this.dataGridViewTextBoxColumn6.HeaderText = "Адрес";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // klientBindingSource
            // 
            this.klientBindingSource.DataSource = typeof(TurGAID.Klient);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(12, 374);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 46);
            this.button1.TabIndex = 2;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.Location = new System.Drawing.Point(133, 374);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 46);
            this.button2.TabIndex = 3;
            this.button2.Text = "Изменить";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button3.Location = new System.Drawing.Point(254, 374);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(115, 46);
            this.button3.TabIndex = 4;
            this.button3.Text = "Удалить";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.LightGreen;
            this.button4.Location = new System.Drawing.Point(617, 374);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(115, 46);
            this.button4.TabIndex = 5;
            this.button4.Text = "Вернуться в главное меню";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button5.Location = new System.Drawing.Point(496, 374);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(115, 46);
            this.button5.TabIndex = 6;
            this.button5.Text = "Выйти из приложения";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Patronymic_checkBox2
            // 
            this.Patronymic_checkBox2.AutoSize = true;
            this.Patronymic_checkBox2.Location = new System.Drawing.Point(339, 486);
            this.Patronymic_checkBox2.Name = "Patronymic_checkBox2";
            this.Patronymic_checkBox2.Size = new System.Drawing.Size(15, 14);
            this.Patronymic_checkBox2.TabIndex = 46;
            this.Patronymic_checkBox2.UseVisualStyleBackColor = true;
            // 
            // Name_checkBox1
            // 
            this.Name_checkBox1.AutoSize = true;
            this.Name_checkBox1.Location = new System.Drawing.Point(339, 459);
            this.Name_checkBox1.Name = "Name_checkBox1";
            this.Name_checkBox1.Size = new System.Drawing.Size(15, 14);
            this.Name_checkBox1.TabIndex = 45;
            this.Name_checkBox1.UseVisualStyleBackColor = true;
            // 
            // Surname_checkBox1
            // 
            this.Surname_checkBox1.AutoSize = true;
            this.Surname_checkBox1.Location = new System.Drawing.Point(339, 431);
            this.Surname_checkBox1.Name = "Surname_checkBox1";
            this.Surname_checkBox1.Size = new System.Drawing.Size(15, 14);
            this.Surname_checkBox1.TabIndex = 44;
            this.Surname_checkBox1.UseVisualStyleBackColor = true;
            // 
            // PatronymiccomboBox2
            // 
            this.PatronymiccomboBox2.DataSource = this.klientBindingSource;
            this.PatronymiccomboBox2.DisplayMember = "Otchestvo";
            this.PatronymiccomboBox2.FormattingEnabled = true;
            this.PatronymiccomboBox2.Location = new System.Drawing.Point(133, 483);
            this.PatronymiccomboBox2.Name = "PatronymiccomboBox2";
            this.PatronymiccomboBox2.Size = new System.Drawing.Size(200, 21);
            this.PatronymiccomboBox2.TabIndex = 43;
            this.PatronymiccomboBox2.ValueMember = "ID_klient";
            // 
            // NamecomboBox1
            // 
            this.NamecomboBox1.DataSource = this.klientBindingSource;
            this.NamecomboBox1.DisplayMember = "Name";
            this.NamecomboBox1.FormattingEnabled = true;
            this.NamecomboBox1.Location = new System.Drawing.Point(133, 456);
            this.NamecomboBox1.Name = "NamecomboBox1";
            this.NamecomboBox1.Size = new System.Drawing.Size(200, 21);
            this.NamecomboBox1.TabIndex = 41;
            this.NamecomboBox1.ValueMember = "ID_klient";
            // 
            // SurnameComboBox
            // 
            this.SurnameComboBox.DataSource = this.klientBindingSource;
            this.SurnameComboBox.DisplayMember = "Familia";
            this.SurnameComboBox.FormattingEnabled = true;
            this.SurnameComboBox.Location = new System.Drawing.Point(133, 429);
            this.SurnameComboBox.Name = "SurnameComboBox";
            this.SurnameComboBox.Size = new System.Drawing.Size(200, 21);
            this.SurnameComboBox.TabIndex = 39;
            this.SurnameComboBox.ValueMember = "ID_klient";
            // 
            // bithday_checkBox4
            // 
            this.bithday_checkBox4.AutoSize = true;
            this.bithday_checkBox4.Location = new System.Drawing.Point(339, 513);
            this.bithday_checkBox4.Name = "bithday_checkBox4";
            this.bithday_checkBox4.Size = new System.Drawing.Size(15, 14);
            this.bithday_checkBox4.TabIndex = 49;
            this.bithday_checkBox4.UseVisualStyleBackColor = true;
            // 
            // adress_checkBox1
            // 
            this.adress_checkBox1.AutoSize = true;
            this.adress_checkBox1.Location = new System.Drawing.Point(339, 539);
            this.adress_checkBox1.Name = "adress_checkBox1";
            this.adress_checkBox1.Size = new System.Drawing.Size(15, 14);
            this.adress_checkBox1.TabIndex = 52;
            this.adress_checkBox1.UseVisualStyleBackColor = true;
            // 
            // address_textBox1
            // 
            this.address_textBox1.Location = new System.Drawing.Point(133, 536);
            this.address_textBox1.Name = "address_textBox1";
            this.address_textBox1.Size = new System.Drawing.Size(200, 20);
            this.address_textBox1.TabIndex = 50;
            // 
            // birthday_dateTimePicker1
            // 
            this.birthday_dateTimePicker1.Location = new System.Drawing.Point(133, 510);
            this.birthday_dateTimePicker1.Name = "birthday_dateTimePicker1";
            this.birthday_dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.birthday_dateTimePicker1.TabIndex = 53;
            // 
            // search_button6
            // 
            this.search_button6.BackColor = System.Drawing.Color.LightGreen;
            this.search_button6.Location = new System.Drawing.Point(17, 562);
            this.search_button6.Name = "search_button6";
            this.search_button6.Size = new System.Drawing.Size(342, 46);
            this.search_button6.TabIndex = 54;
            this.search_button6.Text = "Найти";
            this.search_button6.UseVisualStyleBackColor = false;
            this.search_button6.Click += new System.EventHandler(this.search_button6_Click);
            // 
            // KlientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(744, 617);
            this.Controls.Add(this.search_button6);
            this.Controls.Add(this.birthday_dateTimePicker1);
            this.Controls.Add(this.adress_checkBox1);
            this.Controls.Add(label3);
            this.Controls.Add(this.address_textBox1);
            this.Controls.Add(this.bithday_checkBox4);
            this.Controls.Add(stoimostLabel);
            this.Controls.Add(this.Patronymic_checkBox2);
            this.Controls.Add(this.Name_checkBox1);
            this.Controls.Add(this.Surname_checkBox1);
            this.Controls.Add(label2);
            this.Controls.Add(this.PatronymiccomboBox2);
            this.Controls.Add(label1);
            this.Controls.Add(this.NamecomboBox1);
            this.Controls.Add(iD_klientLabel);
            this.Controls.Add(this.SurnameComboBox);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.klientDataGridView);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(760, 656);
            this.MinimumSize = new System.Drawing.Size(760, 656);
            this.Name = "KlientForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Клиенты";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.KlientForm_FormClosing);
            this.Load += new System.EventHandler(this.KlientForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.klientDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource klientBindingSource;
        private System.Windows.Forms.DataGridView klientDataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.CheckBox Patronymic_checkBox2;
        private System.Windows.Forms.CheckBox Name_checkBox1;
        private System.Windows.Forms.CheckBox Surname_checkBox1;
        private System.Windows.Forms.ComboBox PatronymiccomboBox2;
        private System.Windows.Forms.ComboBox NamecomboBox1;
        private System.Windows.Forms.ComboBox SurnameComboBox;
        private System.Windows.Forms.CheckBox bithday_checkBox4;
        private System.Windows.Forms.CheckBox adress_checkBox1;
        private System.Windows.Forms.TextBox address_textBox1;
        private System.Windows.Forms.DateTimePicker birthday_dateTimePicker1;
        private System.Windows.Forms.Button search_button6;
    }
}