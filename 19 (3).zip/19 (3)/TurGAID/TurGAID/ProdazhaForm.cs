﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class ProdazhaForm : Form
    {
        Model1 DB = new Model1();
        public ProdazhaForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CurrentProdazhaForm frm = new CurrentProdazhaForm();
            frm.DB = DB;
            frm.st = null;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                //prodazhaBindingSource.DataSource = null;
                prodazhaBindingSource.DataSource = DB.Prodazha.ToList();
            }
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Prodazha st = (Prodazha)prodazhaBindingSource.Current;
            CurrentProdazhaForm frm = new CurrentProdazhaForm();
            frm.DB = DB;
            frm.st = st;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                prodazhaBindingSource.DataSource = DB.Prodazha.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Prodazha st = (Prodazha)prodazhaBindingSource.Current;
            DialogResult dr = MessageBox.Show(" Удалить " +
              st.ID_prodazh + "?", " Удаление ",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                DB.Prodazha.Remove(st);
                try
                {
                    DB.SaveChanges();
                    prodazhaBindingSource.DataSource = DB.Prodazha.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.InnerException.InnerException.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainForm frm = new MainForm();
            this.Hide();
            frm.Show();
        }

        private void ProdazhaForm_Load(object sender, EventArgs e)
        {
            this.klientBindingSource.DataSource = this.DB.Klient.ToList();
            this.tyrBindingSource.DataSource = this.DB.Tyr.ToList();
            this.otelBindingSource.DataSource = this.DB.Otel.ToList();
            prodazhaBindingSource.DataSource = DB.Prodazha.ToList();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
            try
            {
                var prodazhi = from prod in DB.Prodazha.ToList()
                           where this.isCorrect(prod)
                           select prod;
            this.prodazhaBindingSource.DataSource = prodazhi.ToList();
            }
            catch (IndexOutOfRangeException ex)
            {
                MessageBox.Show("Заполните параметры для поиска.");
            }
            catch (ArgumentOutOfRangeException ex)
            {
                MessageBox.Show("Заполните параметры для поиска.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неизвестная ошибка! Обратитесь к системному администратору.");
            }
        }
        private bool isCorrect(TurGAID.Prodazha prodazha)
        {
            bool isChecked = false;
            bool isCorrect = true;
            if (ID_Tyr_checkBox1.Checked && (this.DB.Tyr.ToList()[iD_tyrComboBox.SelectedIndex].ID_tyr == prodazha.ID_tyr))
            {
                isCorrect &= true;
                isChecked = true;
            }


            if (Surname_checkBox1.Checked && (this.DB.Klient.ToList()[SurnameComboBox.SelectedIndex].Familia == prodazha.Klient.Familia))
            {
                isCorrect &= true;
                isChecked = true;
            }


            if (Name_checkBox1.Checked && (this.DB.Klient.ToList()[NamecomboBox1.SelectedIndex].Name == prodazha.Klient.Name))
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (Patronymic_checkBox2.Checked && (this.DB.Klient.ToList()[PatronymiccomboBox2.SelectedIndex].Otchestvo == prodazha.Klient.Otchestvo))
            {
                isCorrect &= true;
                isChecked = true;
            }


            if (ID_Otel_checkBox3.Checked && (this.DB.Otel.ToList()[iD_OtelComboBox.SelectedIndex].ID_Otel == prodazha.ID_Otel))
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (Cost_checkBox4.Checked && Convert.ToDecimal(stoimostTextBox.Text) == prodazha.Stoimost)
            {
                isCorrect &= true;
                isChecked = true;
            }

            if (Data_hachela_tura_checkBox5.Checked && Convert.ToDateTime(data_nachalo_tyraDateTimePicker.Value) == prodazha.Data_nachalo_tyra)
            {
                isCorrect &= true;
                isChecked = true;
            }


            if (Data_Prodazhi_tura_checkBox6.Checked && Convert.ToDateTime(data_prodazhiDateTimePicker.Value) == prodazha.Data_prodazhi)
            {
                isCorrect &= true;
                isChecked = true;
            }

            return isCorrect && isChecked;
        }
    }
}
