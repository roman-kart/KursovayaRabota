﻿
namespace TurGAID
{
    partial class CurrentProdazhaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label data_nachalo_tyraLabel;
            System.Windows.Forms.Label data_prodazhiLabel;
            System.Windows.Forms.Label iD_prodazhLabel;
            System.Windows.Forms.Label stoimostLabel;
            System.Windows.Forms.Label iD_klientLabel;
            System.Windows.Forms.Label iD_OtelLabel;
            System.Windows.Forms.Label iD_tyrLabel;
            this.data_nachalo_tyraDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.prodazhaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.data_prodazhiDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.iD_prodazhTextBox = new System.Windows.Forms.TextBox();
            this.stoimostTextBox = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.iD_klientComboBox = new System.Windows.Forms.ComboBox();
            this.klientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iD_OtelComboBox = new System.Windows.Forms.ComboBox();
            this.otelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iD_tyrComboBox = new System.Windows.Forms.ComboBox();
            this.tyrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            data_nachalo_tyraLabel = new System.Windows.Forms.Label();
            data_prodazhiLabel = new System.Windows.Forms.Label();
            iD_prodazhLabel = new System.Windows.Forms.Label();
            stoimostLabel = new System.Windows.Forms.Label();
            iD_klientLabel = new System.Windows.Forms.Label();
            iD_OtelLabel = new System.Windows.Forms.Label();
            iD_tyrLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.prodazhaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.otelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tyrBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // data_nachalo_tyraLabel
            // 
            data_nachalo_tyraLabel.AutoSize = true;
            data_nachalo_tyraLabel.Location = new System.Drawing.Point(26, 120);
            data_nachalo_tyraLabel.Name = "data_nachalo_tyraLabel";
            data_nachalo_tyraLabel.Size = new System.Drawing.Size(99, 13);
            data_nachalo_tyraLabel.TabIndex = 1;
            data_nachalo_tyraLabel.Text = "Дата начала тура:";
            // 
            // data_prodazhiLabel
            // 
            data_prodazhiLabel.AutoSize = true;
            data_prodazhiLabel.Location = new System.Drawing.Point(26, 146);
            data_prodazhiLabel.Name = "data_prodazhiLabel";
            data_prodazhiLabel.Size = new System.Drawing.Size(108, 13);
            data_prodazhiLabel.TabIndex = 3;
            data_prodazhiLabel.Text = "Дата продажи тура:";
            // 
            // iD_prodazhLabel
            // 
            iD_prodazhLabel.AutoSize = true;
            iD_prodazhLabel.Location = new System.Drawing.Point(26, 212);
            iD_prodazhLabel.Name = "iD_prodazhLabel";
            iD_prodazhLabel.Size = new System.Drawing.Size(70, 13);
            iD_prodazhLabel.TabIndex = 9;
            iD_prodazhLabel.Text = "ID Продажи:";
            iD_prodazhLabel.Visible = false;
            // 
            // stoimostLabel
            // 
            stoimostLabel.AutoSize = true;
            stoimostLabel.Location = new System.Drawing.Point(26, 92);
            stoimostLabel.Name = "stoimostLabel";
            stoimostLabel.Size = new System.Drawing.Size(65, 13);
            stoimostLabel.TabIndex = 13;
            stoimostLabel.Text = "Стоимость:";
            // 
            // iD_klientLabel
            // 
            iD_klientLabel.AutoSize = true;
            iD_klientLabel.Location = new System.Drawing.Point(26, 38);
            iD_klientLabel.Name = "iD_klientLabel";
            iD_klientLabel.Size = new System.Drawing.Size(49, 13);
            iD_klientLabel.TabIndex = 13;
            iD_klientLabel.Text = "ID klient:";
            // 
            // iD_OtelLabel
            // 
            iD_OtelLabel.AutoSize = true;
            iD_OtelLabel.Location = new System.Drawing.Point(26, 65);
            iD_OtelLabel.Name = "iD_OtelLabel";
            iD_OtelLabel.Size = new System.Drawing.Size(43, 13);
            iD_OtelLabel.TabIndex = 14;
            iD_OtelLabel.Text = "ID Otel:";
            // 
            // iD_tyrLabel
            // 
            iD_tyrLabel.AutoSize = true;
            iD_tyrLabel.Location = new System.Drawing.Point(26, 11);
            iD_tyrLabel.Name = "iD_tyrLabel";
            iD_tyrLabel.Size = new System.Drawing.Size(35, 13);
            iD_tyrLabel.TabIndex = 15;
            iD_tyrLabel.Text = "ID tyr:";
            // 
            // data_nachalo_tyraDateTimePicker
            // 
            this.data_nachalo_tyraDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.prodazhaBindingSource, "Data_nachalo_tyra", true));
            this.data_nachalo_tyraDateTimePicker.Location = new System.Drawing.Point(145, 116);
            this.data_nachalo_tyraDateTimePicker.Name = "data_nachalo_tyraDateTimePicker";
            this.data_nachalo_tyraDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.data_nachalo_tyraDateTimePicker.TabIndex = 5;
            // 
            // prodazhaBindingSource
            // 
            this.prodazhaBindingSource.DataSource = typeof(TurGAID.Prodazha);
            // 
            // data_prodazhiDateTimePicker
            // 
            this.data_prodazhiDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.prodazhaBindingSource, "Data_prodazhi", true));
            this.data_prodazhiDateTimePicker.Location = new System.Drawing.Point(145, 142);
            this.data_prodazhiDateTimePicker.Name = "data_prodazhiDateTimePicker";
            this.data_prodazhiDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.data_prodazhiDateTimePicker.TabIndex = 6;
            // 
            // iD_prodazhTextBox
            // 
            this.iD_prodazhTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.prodazhaBindingSource, "ID_prodazh", true));
            this.iD_prodazhTextBox.Location = new System.Drawing.Point(145, 209);
            this.iD_prodazhTextBox.Name = "iD_prodazhTextBox";
            this.iD_prodazhTextBox.Size = new System.Drawing.Size(200, 20);
            this.iD_prodazhTextBox.TabIndex = 1;
            this.iD_prodazhTextBox.Visible = false;
            // 
            // stoimostTextBox
            // 
            this.stoimostTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.prodazhaBindingSource, "Stoimost", true));
            this.stoimostTextBox.Location = new System.Drawing.Point(145, 89);
            this.stoimostTextBox.Name = "stoimostTextBox";
            this.stoimostTextBox.Size = new System.Drawing.Size(200, 20);
            this.stoimostTextBox.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(216, 177);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 46);
            this.button2.TabIndex = 8;
            this.button2.Text = "Вернуться";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(43, 177);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 46);
            this.button1.TabIndex = 7;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // iD_klientComboBox
            // 
            this.iD_klientComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.prodazhaBindingSource, "ID_klient", true));
            this.iD_klientComboBox.DataSource = this.klientBindingSource;
            this.iD_klientComboBox.DisplayMember = "Familia";
            this.iD_klientComboBox.FormattingEnabled = true;
            this.iD_klientComboBox.Location = new System.Drawing.Point(145, 35);
            this.iD_klientComboBox.Name = "iD_klientComboBox";
            this.iD_klientComboBox.Size = new System.Drawing.Size(200, 21);
            this.iD_klientComboBox.TabIndex = 14;
            this.iD_klientComboBox.ValueMember = "ID_klient";
            // 
            // klientBindingSource
            // 
            this.klientBindingSource.DataSource = typeof(TurGAID.Klient);
            // 
            // iD_OtelComboBox
            // 
            this.iD_OtelComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.prodazhaBindingSource, "ID_Otel", true));
            this.iD_OtelComboBox.DataSource = this.otelBindingSource;
            this.iD_OtelComboBox.DisplayMember = "Klass_Otel";
            this.iD_OtelComboBox.FormattingEnabled = true;
            this.iD_OtelComboBox.Location = new System.Drawing.Point(145, 62);
            this.iD_OtelComboBox.Name = "iD_OtelComboBox";
            this.iD_OtelComboBox.Size = new System.Drawing.Size(200, 21);
            this.iD_OtelComboBox.TabIndex = 15;
            this.iD_OtelComboBox.ValueMember = "ID_Otel";
            // 
            // otelBindingSource
            // 
            this.otelBindingSource.DataSource = typeof(TurGAID.Otel);
            // 
            // iD_tyrComboBox
            // 
            this.iD_tyrComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.prodazhaBindingSource, "ID_tyr", true));
            this.iD_tyrComboBox.DataSource = this.tyrBindingSource;
            this.iD_tyrComboBox.DisplayMember = "Tyr1";
            this.iD_tyrComboBox.FormattingEnabled = true;
            this.iD_tyrComboBox.Location = new System.Drawing.Point(145, 8);
            this.iD_tyrComboBox.Name = "iD_tyrComboBox";
            this.iD_tyrComboBox.Size = new System.Drawing.Size(200, 21);
            this.iD_tyrComboBox.TabIndex = 16;
            this.iD_tyrComboBox.ValueMember = "ID_tyr";
            // 
            // tyrBindingSource
            // 
            this.tyrBindingSource.DataSource = typeof(TurGAID.Tyr);
            // 
            // CurrentProdazhaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(493, 249);
            this.Controls.Add(iD_tyrLabel);
            this.Controls.Add(this.iD_tyrComboBox);
            this.Controls.Add(iD_OtelLabel);
            this.Controls.Add(this.iD_OtelComboBox);
            this.Controls.Add(iD_klientLabel);
            this.Controls.Add(this.iD_klientComboBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(data_nachalo_tyraLabel);
            this.Controls.Add(this.data_nachalo_tyraDateTimePicker);
            this.Controls.Add(data_prodazhiLabel);
            this.Controls.Add(this.data_prodazhiDateTimePicker);
            this.Controls.Add(iD_prodazhLabel);
            this.Controls.Add(this.iD_prodazhTextBox);
            this.Controls.Add(stoimostLabel);
            this.Controls.Add(this.stoimostTextBox);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(509, 288);
            this.MinimumSize = new System.Drawing.Size(509, 288);
            this.Name = "CurrentProdazhaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Текущая продажа";
            this.Load += new System.EventHandler(this.CurrentProdazhaForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.prodazhaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.otelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tyrBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource prodazhaBindingSource;
        private System.Windows.Forms.DateTimePicker data_nachalo_tyraDateTimePicker;
        private System.Windows.Forms.DateTimePicker data_prodazhiDateTimePicker;
        private System.Windows.Forms.TextBox iD_prodazhTextBox;
        private System.Windows.Forms.TextBox stoimostTextBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox iD_klientComboBox;
        private System.Windows.Forms.ComboBox iD_OtelComboBox;
        private System.Windows.Forms.ComboBox iD_tyrComboBox;
        private System.Windows.Forms.BindingSource klientBindingSource;
        private System.Windows.Forms.BindingSource otelBindingSource;
        private System.Windows.Forms.BindingSource tyrBindingSource;
    }
}