﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class KurortForm : Form
    {
        Model1 DB = new Model1();
        public KurortForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CurrentKurortForm frm = new CurrentKurortForm();
            frm.DB = DB;
            frm.kl = null;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                //kurortBindingSource.DataSource = null;
                kurortBindingSource.DataSource = DB.Kurort.ToList();
            }
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Kurort kl = (Kurort)kurortBindingSource.Current;
            CurrentKurortForm frm = new CurrentKurortForm();
            frm.DB = DB;
            frm.kl = kl;
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            {
                //kurortBindingSource.DataSource = null;
                kurortBindingSource.DataSource = DB.Kurort.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Kurort kl = (Kurort)kurortBindingSource.Current;
            DialogResult dr = MessageBox.Show(" Удалить " +
              kl.ID_Kurort + "?", " Удаление ",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                if (kl.Tyr.Count == 0)
                {
                    DB.Kurort.Remove(kl);
                }
                else
                {
                    MessageBox.Show("Для удаления курорта необходимо удалить связанные с курортом туры!");
                }
                try
                {
                    DB.SaveChanges();
                    kurortBindingSource.DataSource = DB.Kurort.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.InnerException.InnerException.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainForm frm = new MainForm();
            this.Hide();
            frm.Show();
        }

        private void KurortForm_Load(object sender, EventArgs e)
        {
            kurortBindingSource.DataSource = DB.Kurort.ToList();
            stranaBindingSource.DataSource = DB.Strana.ToList();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (this.comboBox1 != null)
            {
                try
                {
                    var selectedIndex = DB.Strana.ToList()[comboBox1.SelectedIndex].ID_strana;
                    var selectedKurorts = from i in DB.Kurort.ToList()
                                          where i.ID_strana == selectedIndex
                                          select i;
                    this.kurortBindingSource.DataSource = selectedKurorts;
                }
                catch (IndexOutOfRangeException ex)
                {
                    MessageBox.Show("Выберите страну для поиска.");
                }
                catch(ArgumentOutOfRangeException ex)
                {
                    MessageBox.Show("Выберите страну для поиска.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Неизвестная ошибка! Обратитесь к системному администратору.");
                }
            }
        }
    }
}
