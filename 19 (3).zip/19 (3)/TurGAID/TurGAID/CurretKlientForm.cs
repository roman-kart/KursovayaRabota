﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurGAID
{
    public partial class CurretKlientForm : Form
    {
        public Model1 DB { get; set; }
        public Klient kl { get; set; }
        public CurretKlientForm()
        {
            InitializeComponent();
        }

        private void CurretKlientForm_Load(object sender, EventArgs e)
        {
            if (kl == null)
            {
                klientBindingSource.AddNew();

                Text = " Добавление нового клиента ";
            }
            else
            {
                klientBindingSource.Add(kl);
                iD_klientTextBox.ReadOnly = true;
                Text = " Корректировка клиента " + kl.ID_klient;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (kl == null)
            {
                kl = (Klient)klientBindingSource.List[0];
                DB.Klient.Add(kl);
            }
            try
            {
                DB.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Ошибка " + ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
