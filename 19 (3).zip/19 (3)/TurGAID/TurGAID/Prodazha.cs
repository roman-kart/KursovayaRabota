namespace TurGAID
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Prodazha")]
    public partial class Prodazha
    {
        [Key]
        public int ID_prodazh { get; set; }

        public int ID_klient { get; set; }

        public int ID_tyr { get; set; }

        [Column(TypeName = "money")]
        public decimal Stoimost { get; set; }

        [Column(TypeName = "date")]
        public DateTime Data_prodazhi { get; set; }

        [Column(TypeName = "date")]
        public DateTime Data_nachalo_tyra { get; set; }

        public int ID_Otel { get; set; }

        public virtual Klient Klient { get; set; }

        public virtual Otel Otel { get; set; }

        public virtual Tyr Tyr { get; set; }
        public override string ToString()
        {
            return $"id_tyr = {ID_tyr}\n" +
                $"prodazha = {ID_prodazh}";
        }
    }
}
