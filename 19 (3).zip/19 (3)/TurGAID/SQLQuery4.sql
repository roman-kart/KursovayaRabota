﻿insert into Prodazha(ID_klient, ID_tyr, ID_Otel, Stoimost, Data_prodazhi, Data_nachalo_tyra)
	values(1, 1, 2, 15000, '2020-05-18', '2020-05-28');

go
select * from Otel;