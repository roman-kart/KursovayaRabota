﻿create table Seasons
(
	id int identity constraint PK_ID_Seasons primary key,
	season_name nvarchar(255) not null
);

go
insert into Seasons(season_name) 
	values('Зима');
insert into Seasons(season_name) 
	values('Весна');
insert into Seasons(season_name) 
	values('Лето');
insert into Seasons(season_name) 
	values('Осень');