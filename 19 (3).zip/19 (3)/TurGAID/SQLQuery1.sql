﻿alter table Klient
	alter column Adres nvarchar(max) not null;